
using SteamServerTool.Core.Services.Deployment;

namespace SteamServerTool.Tests;

public class DeploymentManifestRegistryTests
{
    [Fact]
    public void LoadAll_LoadsTop25PlusNonSteamEntries()
    {
        var manifestDir = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "SteamServerTool.Core", "DeploymentManifests"));
        var registry = new DeploymentManifestRegistry(manifestDir);

        var manifests = registry.LoadAll();

        Assert.True(manifests.Count >= 28);
        Assert.Contains(manifests, m => m.Id == "minecraft-java");
        Assert.Contains(manifests, m => m.Id == "vintagestory");
    }
}
