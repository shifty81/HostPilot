
using SteamServerTool.Core.Services.Discovery;

namespace SteamServerTool.Tests;

public class ManifestBackedServerDetectorTests
{
    [Fact]
    public void ScanPaths_FindsMatchingServerFootprint()
    {
        var tempRoot = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N"));
        var installDir = Path.Combine(tempRoot, "steamapps", "common", "Valheim dedicated server");
        Directory.CreateDirectory(installDir);
        File.WriteAllText(Path.Combine(installDir, "valheim_server.exe"), string.Empty);
        File.WriteAllText(Path.Combine(installDir, "start_headless_server.bat"), string.Empty);

        try
        {
            var signature = new ServerDetectionSignature
            {
                ManifestId = "valheim",
                DisplayName = "Valheim",
                Executables = ["valheim_server.exe"],
                Files = ["start_headless_server.bat"],
                Folders = ["Valheim dedicated server"],
                ConfigFiles = ["start_headless_server.bat"],
                MinimumEvidence = 2,
            };

            var detector = new ManifestBackedServerDetector();
            var results = detector.ScanPaths([tempRoot], [signature]);

            var match = Assert.Single(results);
            Assert.Equal("valheim", match.ManifestId);
            Assert.Contains(match.Evidence, e => e.Contains("Found executable", StringComparison.OrdinalIgnoreCase));
        }
        finally
        {
            if (Directory.Exists(tempRoot))
                Directory.Delete(tempRoot, recursive: true);
        }
    }
}
