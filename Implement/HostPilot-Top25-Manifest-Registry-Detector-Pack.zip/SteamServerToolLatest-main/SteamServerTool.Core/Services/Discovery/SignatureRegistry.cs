
using System.Text.Json;

namespace SteamServerTool.Core.Services.Discovery;

public class SignatureRegistry
{
    private readonly string _directory;

    public SignatureRegistry(string directory)
    {
        _directory = directory;
    }

    public IReadOnlyList<ServerDetectionSignature> LoadAll()
    {
        if (!Directory.Exists(_directory))
            return Array.Empty<ServerDetectionSignature>();

        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true, ReadCommentHandling = JsonCommentHandling.Skip };
        return Directory.EnumerateFiles(_directory, "*.json", SearchOption.TopDirectoryOnly)
            .OrderBy(Path.GetFileName)
            .Select(path => JsonSerializer.Deserialize<ServerDetectionSignature>(File.ReadAllText(path), options))
            .Where(signature => signature is not null)
            .Cast<ServerDetectionSignature>()
            .ToList();
    }
}
