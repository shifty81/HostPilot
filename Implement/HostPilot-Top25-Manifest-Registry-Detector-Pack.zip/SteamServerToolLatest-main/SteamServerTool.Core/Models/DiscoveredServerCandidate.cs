
namespace SteamServerTool.Core.Models;

public class DiscoveredServerCandidate
{
    public string ManifestId { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string InstallPath { get; set; } = "";
    public string ExecutablePath { get; set; } = "";
    public double Confidence { get; set; }
    public List<string> Evidence { get; set; } = new();
    public List<string> SuggestedConfigFiles { get; set; } = new();
}
