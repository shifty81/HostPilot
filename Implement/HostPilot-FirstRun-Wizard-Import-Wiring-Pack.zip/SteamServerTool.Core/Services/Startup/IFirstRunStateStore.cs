using SteamServerTool.Core.Models.FirstRun;

namespace SteamServerTool.Core.Services.Startup;

public interface IFirstRunStateStore
{
    FirstRunWizardState Load();
    void Save(FirstRunWizardState state);
}
