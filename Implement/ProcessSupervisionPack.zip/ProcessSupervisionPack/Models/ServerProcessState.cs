namespace ProcessSupervisionPack.Models;
public enum ServerProcessState
{
    Stopped,
    Starting,
    Running,
    Stopping,
    Crashed
}
