namespace ProcessSupervisionPack.Models;
public enum OperationType
{
    Install,
    Update,
    Validate,
    Start,
    Stop,
    Restart,
    Backup,
    ImportMods
}
