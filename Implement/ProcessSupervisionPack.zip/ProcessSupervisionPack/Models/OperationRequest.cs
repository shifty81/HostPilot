namespace ProcessSupervisionPack.Models;
public sealed class OperationRequest
{
    public Guid OperationId { get; set; } = Guid.NewGuid();
    public string ProfileId { get; set; } = "";
    public OperationType Type { get; set; }
    public Dictionary<string, string> Parameters { get; set; } = new();
}
