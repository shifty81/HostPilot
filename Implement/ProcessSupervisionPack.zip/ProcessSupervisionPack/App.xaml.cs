using System.Windows;
namespace ProcessSupervisionPack;
public partial class App : Application { }
