using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Data;
using System.Windows.Input;
using ProcessSupervisionPack.Commands;
using ProcessSupervisionPack.Models;
using ProcessSupervisionPack.Services;
namespace ProcessSupervisionPack.ViewModels;
public sealed class MainWindowViewModel : ViewModelBase
{
    private readonly ProcessSupervisor _supervisor;
    private readonly OperationQueueService _queue;
    private readonly CancellationTokenSource _cts = new();
    private ServerCardViewModel? _selectedServer;

    public ObservableCollection<ServerCardViewModel> Servers { get; } = new();
    public ObservableCollection<string> Logs { get; } = new();
    public ServerCardViewModel? SelectedServer { get => _selectedServer; set => SetProperty(ref _selectedServer, value); }

    public ICommand InstallCommand { get; }
    public ICommand UpdateCommand { get; }
    public ICommand ValidateCommand { get; }
    public ICommand StartCommand { get; }
    public ICommand StopCommand { get; }
    public ICommand RestartCommand { get; }

    public MainWindowViewModel()
    {
        var profiles = SeedProfiles();
        foreach (var p in profiles) Servers.Add(new ServerCardViewModel(p));
        SelectedServer = Servers.FirstOrDefault();

        _supervisor = new ProcessSupervisor();
        var providers = new ProviderExecutorRegistry();
        _queue = new OperationQueueService(_supervisor, providers, ResolveProfile);
        _queue.Log += m => App.Current.Dispatcher.Invoke(() => Logs.Add($"{DateTime.Now:HH:mm:ss} {m}"));
        _supervisor.StateChanged += (id, state) => App.Current.Dispatcher.Invoke(() =>
        {
            var server = Servers.FirstOrDefault(x => x.ProfileId == id);
            if (server != null) server.State = state;
        });
        _supervisor.OutputReceived += (id, line) => App.Current.Dispatcher.Invoke(() =>
        {
            var server = Servers.FirstOrDefault(x => x.ProfileId == id);
            server?.Output.Add($"[{line.Stream}] {line.Text}");
            Logs.Add($"{DateTime.Now:HH:mm:ss} [{id}] {line.Text}");
        });

        InstallCommand = new RelayCommand(_ => Queue(OperationType.Install), _ => SelectedServer != null);
        UpdateCommand = new RelayCommand(_ => Queue(OperationType.Update), _ => SelectedServer != null);
        ValidateCommand = new RelayCommand(_ => Queue(OperationType.Validate), _ => SelectedServer != null);
        StartCommand = new RelayCommand(_ => Queue(OperationType.Start), _ => SelectedServer != null);
        StopCommand = new RelayCommand(_ => Queue(OperationType.Stop), _ => SelectedServer != null);
        RestartCommand = new RelayCommand(_ => Queue(OperationType.Restart), _ => SelectedServer != null);

        _ = _queue.RunAsync(_cts.Token);
        BindingOperations.EnableCollectionSynchronization(Logs, new object());
    }

    private void Queue(OperationType type)
    {
        if (SelectedServer == null) return;
        _queue.Enqueue(new OperationRequest { ProfileId = SelectedServer.ProfileId, Type = type });
    }

    private DeploymentProfile? ResolveProfile(string id) => Servers.FirstOrDefault(x => x.ProfileId == id)?.Profile;

    private static List<DeploymentProfile> SeedProfiles() =>
    [
        new DeploymentProfile
        {
            DisplayName = "ARK Cluster Node A",
            InstallRoot = @"C:\Servers\ArkA",
            ServerExecutable = "ShooterGameServer.exe",
            LaunchArguments = "TheIsland_WP?listen?SessionName=ArkA -NoBattlEye -server",
            SteamAppId = "376030"
        },
        new DeploymentProfile
        {
            DisplayName = "Vintage Story Test",
            InstallRoot = @"C:\Servers\VintageStory",
            ServerExecutable = "VintagestoryServer.exe",
            LaunchArguments = "--dataPath ./Data",
            ProviderType = "SteamCmd",
            SteamAppId = "3021520"
        }
    ];
}
