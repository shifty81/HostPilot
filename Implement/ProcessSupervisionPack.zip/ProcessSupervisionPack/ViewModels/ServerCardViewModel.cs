using System.Collections.ObjectModel;
using ProcessSupervisionPack.Models;
namespace ProcessSupervisionPack.ViewModels;
public sealed class ServerCardViewModel : ViewModelBase
{
    private ServerProcessState _state;
    public DeploymentProfile Profile { get; }
    public ObservableCollection<string> Output { get; } = new();
    public string DisplayName => Profile.DisplayName;
    public string ProfileId => Profile.ProfileId;
    public ServerProcessState State { get => _state; set => SetProperty(ref _state, value); }
    public ServerCardViewModel(DeploymentProfile profile)
    {
        Profile = profile;
        State = ServerProcessState.Stopped;
    }
}
