using ProcessSupervisionPack.Models;
namespace ProcessSupervisionPack.Services;
public interface IProviderExecutor
{
    Task ExecuteInstallAsync(DeploymentProfile profile, IProgress<string> progress, CancellationToken cancellationToken);
    Task ExecuteUpdateAsync(DeploymentProfile profile, IProgress<string> progress, CancellationToken cancellationToken);
    Task ExecuteValidateAsync(DeploymentProfile profile, IProgress<string> progress, CancellationToken cancellationToken);
}
