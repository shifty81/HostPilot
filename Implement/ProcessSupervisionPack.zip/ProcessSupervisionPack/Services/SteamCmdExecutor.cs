using ProcessSupervisionPack.Models;
namespace ProcessSupervisionPack.Services;
public sealed class SteamCmdExecutor : IProviderExecutor
{
    public async Task ExecuteInstallAsync(DeploymentProfile profile, IProgress<string> progress, CancellationToken cancellationToken)
    {
        progress.Report($"SteamCMD install starting for AppId {profile.SteamAppId}...");
        await Task.Delay(500, cancellationToken);
        progress.Report("Ensure SteamCMD is present.");
        await Task.Delay(500, cancellationToken);
        progress.Report($"app_update {profile.SteamAppId} validate");
        await Task.Delay(700, cancellationToken);
        progress.Report("Install complete.");
    }

    public async Task ExecuteUpdateAsync(DeploymentProfile profile, IProgress<string> progress, CancellationToken cancellationToken)
    {
        progress.Report($"SteamCMD update for AppId {profile.SteamAppId}...");
        await Task.Delay(700, cancellationToken);
        progress.Report("Update complete.");
    }

    public async Task ExecuteValidateAsync(DeploymentProfile profile, IProgress<string> progress, CancellationToken cancellationToken)
    {
        progress.Report("Validating install layout...");
        await Task.Delay(500, cancellationToken);
        progress.Report($"Expected root: {profile.InstallRoot}");
        await Task.Delay(400, cancellationToken);
        progress.Report("Validation complete.");
    }
}
