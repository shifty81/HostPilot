using System.Collections.Concurrent;
using ProcessSupervisionPack.Models;
namespace ProcessSupervisionPack.Services;
public sealed class OperationQueueService
{
    private readonly ConcurrentQueue<OperationRequest> _queue = new();
    private readonly SemaphoreSlim _signal = new(0);
    private readonly ProcessSupervisor _supervisor;
    private readonly ProviderExecutorRegistry _providers;
    private readonly Func<string, DeploymentProfile?> _profileResolver;

    public event Action<string>? Log;

    public OperationQueueService(ProcessSupervisor supervisor, ProviderExecutorRegistry providers, Func<string, DeploymentProfile?> profileResolver)
    {
        _supervisor = supervisor;
        _providers = providers;
        _profileResolver = profileResolver;
    }

    public void Enqueue(OperationRequest request)
    {
        _queue.Enqueue(request);
        _signal.Release();
    }

    public async Task RunAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            await _signal.WaitAsync(cancellationToken);
            if (!_queue.TryDequeue(out var request))
                continue;

            var profile = _profileResolver(request.ProfileId);
            if (profile == null)
            {
                Log?.Invoke($"Profile not found: {request.ProfileId}");
                continue;
            }

            Log?.Invoke($"Dequeued {request.Type} for {profile.DisplayName}");
            var progress = new Progress<string>(m => Log?.Invoke($"[{profile.DisplayName}] {m}"));
            var provider = _providers.Get(profile.ProviderType);

            switch (request.Type)
            {
                case OperationType.Install:
                    await provider.ExecuteInstallAsync(profile, progress, cancellationToken);
                    break;
                case OperationType.Update:
                    await provider.ExecuteUpdateAsync(profile, progress, cancellationToken);
                    break;
                case OperationType.Validate:
                    await provider.ExecuteValidateAsync(profile, progress, cancellationToken);
                    break;
                case OperationType.Start:
                    await _supervisor.StartAsync(profile, cancellationToken);
                    break;
                case OperationType.Stop:
                    await _supervisor.StopAsync(profile.ProfileId, cancellationToken);
                    break;
                case OperationType.Restart:
                    await _supervisor.StopAsync(profile.ProfileId, cancellationToken);
                    await _supervisor.StartAsync(profile, cancellationToken);
                    break;
                case OperationType.Backup:
                    Log?.Invoke($"[{profile.DisplayName}] Backup scaffold placeholder.");
                    break;
                case OperationType.ImportMods:
                    Log?.Invoke($"[{profile.DisplayName}] Mod import scaffold placeholder.");
                    break;
            }
        }
    }
}
