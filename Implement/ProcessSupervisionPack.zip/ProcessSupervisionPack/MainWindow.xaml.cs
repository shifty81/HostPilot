using System.Windows;
using ProcessSupervisionPack.ViewModels;
namespace ProcessSupervisionPack;
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainWindowViewModel();
    }
}
