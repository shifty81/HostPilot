# Process Supervision + Provider Execution Pack

This pack is the next layer after the operation queue scaffold.

Included:
- background process supervision service
- auto-restart on crash scaffold
- provider executor abstraction
- SteamCMD executor scaffold
- WPF dashboard for install/update/validate/start/stop/restart
- seeded deployment profiles

## Where to replace scaffolds

### SteamCmdExecutor
Replace the simulated delays with real SteamCMD process execution.
Recommended flow:
1. resolve steamcmd.exe path
2. ensure install root exists
3. run `+force_install_dir <path> +login anonymous +app_update <id> validate +quit`
4. stream stdout/stderr back into the queue log
5. parse progress markers when possible

### ProcessSupervisor
Current stop behavior hard-kills the process tree.
Upgrade path:
- send graceful shutdown command over stdin or RCON where supported
- wait a timeout window
- fall back to kill if needed
- add health probe support and watchdog restart policy

### Real server support
Add per-server launch builders so ARK, Minecraft, Vintage Story, etc. each construct correct startup commands from deployment profile values.

## Notes
This project was prepared in a non-Windows environment and was not desktop-build tested here. It is structured for Visual Studio on Windows.
