using HostPilot.Web.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddSignalR();
builder.Services.AddSingleton<NodeDashboardStore>();
builder.Services.AddAuthentication("Cookies").AddCookie("Cookies");
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("RemoteControl", policy => policy.RequireAuthenticatedUser());
});

var app = builder.Build();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();
app.MapHub<RuntimeEventsHub>("/hubs/runtime-events");
app.MapGet("/api/nodes", (NodeDashboardStore store) => Results.Ok(store.GetNodes())).RequireAuthorization("RemoteControl");

app.Run();
