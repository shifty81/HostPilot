using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HostPilot.Web.Pages;

public sealed class LiveModel : PageModel
{
    public void OnGet()
    {
    }
}
