using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HostPilot.Web.Pages;

public sealed class IndexModel : PageModel
{
    public void OnGet()
    {
    }
}
