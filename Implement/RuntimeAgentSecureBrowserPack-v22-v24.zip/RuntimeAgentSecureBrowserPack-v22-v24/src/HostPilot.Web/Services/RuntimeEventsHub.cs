using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace HostPilot.Web.Services;

[Authorize(Policy = "RemoteControl")]
public sealed class RuntimeEventsHub : Hub
{
    public Task SubscribeNode(string nodeId)
    {
        return Groups.AddToGroupAsync(Context.ConnectionId, $"node:{nodeId}");
    }

    public Task UnsubscribeNode(string nodeId)
    {
        return Groups.RemoveFromGroupAsync(Context.ConnectionId, $"node:{nodeId}");
    }
}
