# v22 Remote Agent Service

## Purpose

The remote agent is the installable runtime that lives on each managed machine and exposes a narrow, controlled execution surface to the main application.

## Responsibilities

- register node identity with controller
- renew lease / heartbeat
- report capabilities and environment details
- accept approved commands
- emit command progress
- return artifacts/paths/metrics
- publish local health snapshots
- enforce local authorization guardrails

## Suggested hosted model

- .NET Worker Service for Windows Service deployment
- optional tray/debug mode for local development
- background loops:
  - heartbeat loop
  - command intake loop
  - event flush loop
  - health sampling loop

## Command categories

- install/update dedicated server
- start/stop/restart instance
- run backup task
- validate mods/plugins
- collect diagnostics bundle
- rotate logs
- refresh workshop content

## Non-goals

- arbitrary remote desktop
- arbitrary shell execution
- unconstrained file browsing outside approved roots
