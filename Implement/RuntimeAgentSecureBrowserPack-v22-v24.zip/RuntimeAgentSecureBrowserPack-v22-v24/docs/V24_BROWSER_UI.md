# v24 Browser UI Pack

## Target experience

A browser-based runtime control surface for local LAN, VPN, or internet-exposed deployments behind proper auth.

## Primary pages

- Sign in
- Dashboard
- Nodes
- Node Detail
- Operations
- Live Events
- Alerts
- Audit
- Settings

## UX expectations

- dark-mode first
- card-heavy monitoring layout
- real-time status chips
- clearly separated dangerous actions
- role-aware command availability
- mobile/tablet friendly enough for remote admin checks

## Recommended stack

- ASP.NET Core MVC or Razor Components
- SignalR for live events
- shared DTOs with WPF/app layer
- auth via cookie + token backend or external identity provider later
