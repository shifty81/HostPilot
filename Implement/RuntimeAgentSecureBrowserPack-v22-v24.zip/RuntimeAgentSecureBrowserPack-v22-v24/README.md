# Runtime Agent Secure Browser Pack v22-v24

This pack extends the standalone server admin application with:

- **v22 Remote Agent Service**: a Windows service/worker-style remote node agent scaffold that can register with a controller, maintain heartbeats, execute bounded tasks, and stream logs/status.
- **v23 Secure Transport**: mutual-auth capable transport abstractions, message signing/envelope models, certificate/token validation hook points, replay protection, and authorization policy surfaces.
- **v24 Browser UI Pack**: ASP.NET Core browser dashboard starter with node list/detail pages, live event feed, command forms, auth shell, and API proxy patterns.

The pack is deliberately compile-oriented scaffold code rather than pretending to be production-complete. It is designed to drop into your repo and be wired into the existing:

- operation queue
- deployment/install lifecycle
- process supervision
- backups
- notifications
- remote nodes / web runtime control pack (v19-v21)

---

## Suggested repo placement

```text
src/
  HostPilot.Core/
  HostPilot.Application/
  HostPilot.Remote.Contracts/
  HostPilot.Remote.Agent/
  HostPilot.Remote.Transport/
  HostPilot.Web/
  HostPilot.Wpf/
```

Replace `HostPilot` with the actual solution namespace you settle on.

---

## Pack layout

```text
RuntimeAgentSecureBrowserPack-v22-v24/
  docs/
  src/
    HostPilot.Remote.Contracts/
    HostPilot.Remote.Agent/
    HostPilot.Remote.Transport/
    HostPilot.Web/
    HostPilot.Wpf/
  tests/
```

---

## v22 goals

- remote node worker that can run as service later
- controller registration + lease renewal
- capability reporting
- bounded command execution pipeline
- log/event shipping
- local health snapshot publishing
- secure command intake boundary

## v23 goals

- signed message envelopes
- nonce/replay prevention hooks
- transport auth policies
- certificate/token abstraction surface
- per-command authorization evaluation
- secure websocket / SignalR-compatible channel shape

## v24 goals

- browser dashboard shell
- node inventory page
- node detail page
- live event stream page
- remote command panels
- auth/role-aware layout
- future multi-tenant-ready component seams

---

## Integration order

1. Add contracts project.
2. Add secure transport project.
3. Add remote agent and wire health/process/install services.
4. Add web project pages/controllers/hubs.
5. Point WPF shell to the same application services for parity.
6. Replace mock certificate/token validators.
7. Add persistent storage for node leases, command history, and audit.

---

## Important implementation notes

- Do **not** allow arbitrary shell command execution from the browser.
- Keep command execution whitelisted and manifest-backed.
- Require server/node scoping on every action.
- Record every remote action to audit history.
- Prefer short-lived access tokens plus device/node credentials.
- Isolate agent execution with constrained service permissions.
- Use Job Objects and existing supervision layers for spawned server processes.
