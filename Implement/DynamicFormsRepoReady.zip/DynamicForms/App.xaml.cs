using System.Windows;

namespace DynamicForms;

public partial class App : Application
{
}
