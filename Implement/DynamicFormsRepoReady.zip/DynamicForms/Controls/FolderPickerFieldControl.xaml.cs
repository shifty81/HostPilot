using System.Windows.Controls;

namespace DynamicForms.Controls;

public partial class FolderPickerFieldControl : UserControl
{
    public FolderPickerFieldControl()
    {
        InitializeComponent();
    }
}
