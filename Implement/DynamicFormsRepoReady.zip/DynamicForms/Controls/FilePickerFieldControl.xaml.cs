using System.Windows.Controls;

namespace DynamicForms.Controls;

public partial class FilePickerFieldControl : UserControl
{
    public FilePickerFieldControl()
    {
        InitializeComponent();
    }
}
