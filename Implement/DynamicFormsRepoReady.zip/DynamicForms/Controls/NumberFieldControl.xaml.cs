using System.Windows.Controls;

namespace DynamicForms.Controls;

public partial class NumberFieldControl : UserControl
{
    public NumberFieldControl()
    {
        InitializeComponent();
    }
}
