using System.Windows.Controls;

namespace DynamicForms.Views;

public partial class DynamicManifestFormHost : UserControl
{
    public DynamicManifestFormHost()
    {
        InitializeComponent();
    }
}
