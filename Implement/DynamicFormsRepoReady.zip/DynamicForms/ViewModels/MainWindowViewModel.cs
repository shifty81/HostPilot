using System;
using System.IO;
using System.Windows.Input;
using DynamicForms.Commands;
using DynamicForms.Services;

namespace DynamicForms.ViewModels;

public sealed class MainWindowViewModel : ViewModelBase
{
    private readonly ManifestLoader _manifestLoader = new();

    public DynamicFormViewModel Form { get; } = new();

    public ICommand LoadSampleManifestCommand { get; }

    public MainWindowViewModel()
    {
        LoadSampleManifestCommand = new RelayCommand(_ => LoadSampleManifest());
        LoadSampleManifest();
    }

    private void LoadSampleManifest()
    {
        var baseDir = AppDomain.CurrentDomain.BaseDirectory;
        var path = Path.Combine(baseDir, "sample-manifest.json");

        if (!File.Exists(path))
        {
            return;
        }

        var manifest = _manifestLoader.LoadFromFile(path);
        Form.Load(manifest);
    }
}
