using System.Collections.Generic;
using DynamicForms.Models;

namespace DynamicForms.Services;

public sealed class ManifestDocument
{
    public List<ManifestTabDto> Tabs { get; set; } = new();
    public List<ManifestFieldDto> Fields { get; set; } = new();
    public List<ManifestRuleDto> Rules { get; set; } = new();
}
