# DynamicForms

Compile-ready WPF MVVM scaffold for manifest-driven dynamic forms.

## What is included

- Manifest-driven field rendering
- MVVM viewmodels
- Custom controls for file, folder, and number fields
- Template selector for field types
- Rule engine for simple show/hide/enable/disable logic
- Validation service
- Sample manifest loader and export preview

## Build

Open `DynamicForms.csproj` in Visual Studio 2022+ on Windows and run.

Target framework:
- `net8.0-windows`

## Core extension points

- `Models/DynamicFieldType.cs`
- `Controls/FieldTemplateSelector.cs`
- `ViewModels/FieldViewModel.cs`
- `Services/DynamicFormRuleEngine.cs`
- `sample-manifest.json`

## Good next additions

- Port-specific control
- True password box handling
- Key/value list editor
- Tag editor for mods/admins
- Stronger conditional logic in the rule engine
- `INotifyDataErrorInfo` validation
