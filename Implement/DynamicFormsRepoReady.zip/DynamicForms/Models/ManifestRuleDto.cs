namespace DynamicForms.Models;

public sealed class ManifestRuleDto
{
    public string Action { get; set; } = string.Empty;
    public string TargetKey { get; set; } = string.Empty;
    public string SourceKey { get; set; } = string.Empty;
    public string? Equals { get; set; }
}
