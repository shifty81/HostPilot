namespace DynamicForms.Models;

public enum DynamicFieldType
{
    Text,
    MultilineText,
    Number,
    Decimal,
    Checkbox,
    Dropdown,
    Password,
    FilePath,
    FolderPath
}
