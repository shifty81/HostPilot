using System.Windows;
using DynamicForms.ViewModels;

namespace DynamicForms;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainWindowViewModel();
    }
}
