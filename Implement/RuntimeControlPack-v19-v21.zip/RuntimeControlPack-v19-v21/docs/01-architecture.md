# v19-v21 Architecture Overview

## v19 Remote Nodes

Remote nodes are separate machines capable of:
- hosting one or more managed game servers
- reporting installed providers / runtimes / ports / mods / storage
- accepting secure commands from the controller app
- publishing live runtime events back to the controller

### Core runtime parts
- `RemoteNodeRegistry` keeps the known nodes list
- `RemoteNodeLeaseService` manages heartbeat freshness
- `RemoteCommandRouter` selects local vs remote execution
- `NodeCommandEnvelope` provides a transport-neutral contract

## v20 Web Runtime Control

The web layer exposes a secured runtime surface for:
- dashboard summaries
- node health
- server lifecycle actions
- automation reads and writes
- logs / notifications / recent operations

### API shape
- REST for query and command submission
- SignalR for live dashboards, logs, and notifications

## v21 Fleet Orchestration

The orchestration layer sits above single-server control and enables:
- fan-out commands to multiple nodes
- grouped deployment workflows
- rolling restart sequences
- cluster-aware actions
- correlated operation history

### Key principle
Every command should produce:
- correlation id
- actor / origin
- target scope
- audit trail entry
- status progression events
