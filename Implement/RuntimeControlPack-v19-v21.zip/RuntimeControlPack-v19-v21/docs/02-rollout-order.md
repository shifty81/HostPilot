# Rollout Order

1. Add shared contracts project.
2. Wire local app services against contracts.
3. Add node registry + heartbeat services.
4. Add web API host with read-only endpoints first.
5. Add SignalR hub for notifications and node state.
6. Add authenticated command endpoints.
7. Add remote agent transport implementation.
8. Add multi-node orchestration and rolling actions.
9. Add audit log persistence and retention policy.
10. Add browser UI or tablet-friendly frontend if desired.
