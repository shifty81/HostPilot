# Runtime Control Pack v19-v21

This pack extends the standalone server admin application with:

- **v19 – Remote Nodes**
  - node registry
  - node capability handshake
  - heartbeat + lease model
  - remote agent command channel contracts
- **v20 – Web Runtime Control**
  - ASP.NET Core control API scaffold
  - SignalR runtime events hub
  - auth/permission model contracts
  - DTOs for dashboard, node state, deployment, logs, and automation execution
- **v21 – Fleet Orchestration Foundation**
  - multi-node targeting
  - remote operation dispatch
  - job tracking / correlation
  - queue-ready orchestration service interfaces

## Design intent

This is scoped for the **standalone server admin project** only.
It does **not** assume integration with Atlas, Master Repo, or game tooling.

## Suggested project mapping

- `HostPilot.Contracts` → shared DTOs/contracts for app + web + agent
- `HostPilot.Runtime` → orchestration, node services, auth abstractions, event fanout
- `HostPilot.Web` → ASP.NET Core web host / API / SignalR / auth wiring
- `HostPilot.App` → WPF runtime control screens and viewmodels
- `tests` → baseline test skeletons
- `docs` → implementation notes and rollout order

## Next recommended pass

- real HTTPS certificate/bootstrap flow
- JWT/session auth implementation
- remote agent Windows service worker
- secure websocket/event streaming
- provider-specific remote action execution adapters
