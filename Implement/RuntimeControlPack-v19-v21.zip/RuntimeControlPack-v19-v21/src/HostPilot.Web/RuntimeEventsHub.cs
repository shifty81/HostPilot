using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace HostPilot.Web;

public sealed class RuntimeEventsHub : Hub
{
    public Task SubscribeToNode(string nodeId)
        => Groups.AddToGroupAsync(Context.ConnectionId, $"node:{nodeId}");

    public Task SubscribeToServer(string serverId)
        => Groups.AddToGroupAsync(Context.ConnectionId, $"server:{serverId}");
}
