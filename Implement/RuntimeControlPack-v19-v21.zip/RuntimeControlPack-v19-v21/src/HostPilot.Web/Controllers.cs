using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using HostPilot.Contracts;
using HostPilot.Runtime;
using Microsoft.AspNetCore.Mvc;

namespace HostPilot.Web.Controllers;

[ApiController]
[Route("api/dashboard")]
public sealed class DashboardController : ControllerBase
{
    private readonly IRemoteNodeRegistry _registry;

    public DashboardController(IRemoteNodeRegistry registry)
    {
        _registry = registry;
    }

    [HttpGet("summary")]
    public ActionResult<DashboardSummaryDto> GetSummary()
    {
        var nodes = _registry.GetAll();
        return Ok(new DashboardSummaryDto
        {
            TotalNodes = nodes.Count,
            OnlineNodes = nodes.Count(x => x.Status == RemoteNodeStatus.Online),
            OfflineNodes = nodes.Count(x => x.Status == RemoteNodeStatus.Offline),
            TotalServers = 0,
            RunningServers = 0,
            ActiveOperations = 0,
            ActiveAlerts = 0
        });
    }
}

[ApiController]
[Route("api/nodes")]
public sealed class NodesController : ControllerBase
{
    private readonly IRemoteNodeRegistry _registry;
    private readonly IRemoteNodeLeaseService _leaseService;

    public NodesController(IRemoteNodeRegistry registry, IRemoteNodeLeaseService leaseService)
    {
        _registry = registry;
        _leaseService = leaseService;
    }

    [HttpGet]
    public ActionResult GetAll() => Ok(_registry.GetAll());

    [HttpPost("heartbeat")]
    public IActionResult Heartbeat([FromBody] NodeHeartbeatDto heartbeat)
    {
        _leaseService.RecordHeartbeat(heartbeat);
        return Accepted();
    }

    [HttpPost("register")]
    public IActionResult Register([FromBody] RemoteNodeDto node)
    {
        _registry.Upsert(node);
        return Accepted(node);
    }
}

[ApiController]
[Route("api/operations")]
public sealed class OperationsController : ControllerBase
{
    private readonly IRemoteCommandRouter _router;

    public OperationsController(IRemoteCommandRouter router)
    {
        _router = router;
    }

    [HttpPost("dispatch")]
    public async Task<ActionResult<OperationStatusDto>> DispatchAsync([FromBody] NodeCommandEnvelope command, CancellationToken cancellationToken)
    {
        var result = await _router.DispatchAsync(command, cancellationToken);
        return Accepted(result);
    }
}
