using HostPilot.Runtime;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddSignalR();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<IRemoteNodeRegistry, RemoteNodeRegistry>();
builder.Services.AddSingleton<IRemoteNodeLeaseService, RemoteNodeLeaseService>();
builder.Services.AddSingleton<IWebAuditService, InMemoryAuditService>();
builder.Services.AddSingleton<IRemoteNodeTransport, StubRemoteNodeTransport>();
builder.Services.AddSingleton<IRemoteCommandRouter, RemoteCommandRouter>();
builder.Services.AddSingleton<IAuthorizationPolicyService, AuthorizationPolicyService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapControllers();
app.MapHub<RuntimeEventsHub>("/hubs/runtime");
app.Run();
