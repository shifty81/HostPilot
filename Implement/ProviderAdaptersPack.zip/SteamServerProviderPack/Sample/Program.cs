using SteamServerProviderPack.Core;
using SteamServerProviderPack.Models;

var registry = new ProviderRegistry();

var profile = new DeploymentProfile
{
    ProviderId = "rust",
    DisplayName = "My Rust Test Server",
    InstallDirectory = @"C:\Servers\Rust01",
    ExecutablePath = @"C:\Servers\Rust01\RustDedicated.exe",
    GamePort = 28015,
    QueryPort = 28016,
    RconPort = 28017,
    RconPassword = "change-me",
    Values = new Dictionary<string, object?>
    {
        ["hostname"] = "My Rust Test Server",
        ["serverIdentity"] = "rust01",
        ["worldSeed"] = 8675309,
        ["worldSize"] = 4250,
        ["extraArgs"] = "+server.maxplayers 50"
    }
};

var provider = registry.GetRequired(profile.ProviderId);
Console.WriteLine($"Provider: {provider.DisplayName}");
Console.WriteLine($"Install: {provider.BuildInstallCommand(profile, @"C:\SteamCMD\steamcmd.exe")}");
Console.WriteLine($"Start:   {provider.BuildStartCommand(profile)}");
Console.WriteLine("Stop plan:");
foreach (var step in provider.BuildGracefulStopPlan(profile))
{
    Console.WriteLine($" - {step.CommandText}");
}

var demoLines = new[]
{
    "Server startup complete",
    "saving complete",
    "fatal exception"
};

Console.WriteLine();
Console.WriteLine("Parser demo:");
foreach (var line in demoLines)
{
    var parsed = provider.LogParser.Parse(line);
    Console.WriteLine($"[{parsed.Severity}] ready={parsed.IndicatesReady} stopping={parsed.IndicatesStopping} crash={parsed.IndicatesCrash} :: {parsed.Message}");
}
