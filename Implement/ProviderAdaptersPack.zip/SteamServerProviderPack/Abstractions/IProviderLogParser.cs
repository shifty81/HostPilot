using SteamServerProviderPack.Models;

namespace SteamServerProviderPack.Abstractions;

public interface IProviderLogParser
{
    string ProviderId { get; }
    ParsedLogEvent Parse(string line);
}
