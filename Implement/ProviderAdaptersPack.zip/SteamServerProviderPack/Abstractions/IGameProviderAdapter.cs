using SteamServerProviderPack.Models;

namespace SteamServerProviderPack.Abstractions;

public interface IGameProviderAdapter
{
    string Id { get; }
    string DisplayName { get; }
    string InstallChannel { get; }
    int? SteamAppId { get; }
    IProviderLogParser LogParser { get; }

    ProviderCommand BuildInstallCommand(DeploymentProfile profile, string steamCmdPath);
    ProviderCommand BuildUpdateCommand(DeploymentProfile profile, string steamCmdPath);
    ProviderCommand BuildValidateCommand(DeploymentProfile profile, string steamCmdPath);
    ProviderCommand BuildStartCommand(DeploymentProfile profile);
    IReadOnlyList<RconCommandPlan> BuildGracefulStopPlan(DeploymentProfile profile);
    bool CanUseRconStop(DeploymentProfile profile);
    string BuildHumanSummary(DeploymentProfile profile);
}
