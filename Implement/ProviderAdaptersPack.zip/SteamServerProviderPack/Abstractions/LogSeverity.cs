namespace SteamServerProviderPack.Abstractions;

public enum LogSeverity
{
    Trace,
    Info,
    Warning,
    Error,
    Success
}
