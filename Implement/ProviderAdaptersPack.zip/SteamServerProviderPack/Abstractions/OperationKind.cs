namespace SteamServerProviderPack.Abstractions;

public enum OperationKind
{
    Install,
    Update,
    Validate,
    Start,
    Stop,
    Restart,
    Status,
    Backup,
    ModSync
}
