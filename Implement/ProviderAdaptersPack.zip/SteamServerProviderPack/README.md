# Provider Adapters + Per-Game Parser Pack

This pack adds a clean adapter layer so each supported game can own its own:

- SteamCMD install / update / validate logic
- start command generation
- graceful stop plan
- output parsing rules
- human summary text

## Included providers

- ARK: Survival Ascended
- Rust
- Valheim
- Source Engine
- Palworld

## Core concepts

- `IGameProviderAdapter` is the main abstraction.
- `IProviderLogParser` converts raw stdout into lifecycle / crash / ready events.
- `ProviderRegistry` resolves the provider by id from a deployment profile.
- `ProviderCommand` is a normalized process launch description.
- `RconCommandPlan` is the ordered graceful shutdown sequence.

## How to wire this into the existing packs

1. When a deployment profile is loaded, resolve `profile.ProviderId` through `ProviderRegistry`.
2. Use `BuildInstallCommand`, `BuildUpdateCommand`, and `BuildValidateCommand` from the queue operation handlers.
3. Use `BuildStartCommand` from the process supervision layer.
4. Stream stdout/stderr through `provider.LogParser.Parse(line)`.
5. If the provider supports RCON stop, execute `BuildGracefulStopPlan(profile)` in order.
6. Fall back to timeout + process kill when stop does not complete.

## Notes by provider

### ARK: Survival Ascended
- Uses SteamCMD app id `2430930`.
- Shutdown plan assumes RCON/admin command support is available in your implementation.
- Map/session options should come from the deployment manifest layer.

### Rust
- Uses SteamCMD app id `258550`.
- Stop plan is `server.save` then `quit`.
- Parser looks for startup completion and crash-like lines.

### Valheim
- Uses SteamCMD app id `896660`.
- No RCON stop scaffold included here, so this provider intentionally falls back to process supervision logic.
- Extend this later if you adopt a mod/plugin admin bridge.

### Source Engine
- Uses SteamCMD app id `232330` here as a generic Source DS base scaffold.
- In production you will likely split this into title-specific providers such as CS:GO / CSS / TF2 / HL2DM.

### Palworld
- Uses SteamCMD app id `2394010`.
- Shutdown plan uses `Save` then `Shutdown 1 ...` as a starting pattern.
- Startup flags include common dedicated performance flags.

## Expected next refinement

The next real upgrade is to split some of these into title-specific providers instead of umbrella adapters. The most obvious target is Source-based titles, and possibly separate providers for ARK Survival Evolved vs Ascended.

## Build note

This is designed as a repo-ready code pack. It was assembled in a non-Windows environment and not fully integration-tested against live server binaries.
