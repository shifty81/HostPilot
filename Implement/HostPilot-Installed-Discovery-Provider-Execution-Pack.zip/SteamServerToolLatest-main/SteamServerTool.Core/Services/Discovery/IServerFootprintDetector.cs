using SteamServerTool.Core.Models.Discovery;

namespace SteamServerTool.Core.Services.Discovery;

public interface IServerFootprintDetector
{
    string ServerType { get; }
    Task<IReadOnlyList<DiscoveredServerCandidate>> ScanAsync(IEnumerable<string> roots, CancellationToken cancellationToken = default);
}
