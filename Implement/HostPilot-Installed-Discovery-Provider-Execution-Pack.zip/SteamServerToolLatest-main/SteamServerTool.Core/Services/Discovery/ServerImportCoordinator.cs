using SteamServerTool.Core.Models;
using SteamServerTool.Core.Models.Discovery;

namespace SteamServerTool.Core.Services.Discovery;

public sealed class ServerImportCoordinator
{
    public ServerConfig BuildImportedConfig(DiscoveredServerCandidate candidate)
    {
        return new ServerConfig
        {
            Name = string.IsNullOrWhiteSpace(candidate.DisplayName)
                ? Path.GetFileName(candidate.InstallPath)
                : candidate.DisplayName,
            InstallDirectory = candidate.InstallPath,
            ExecutablePath = candidate.ExecutablePath,
            Status = "Imported",
            GameType = candidate.ServerType,
            Notes = $"Imported existing server on {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC",
            AutoStart = false,
            IsModded = Directory.Exists(Path.Combine(candidate.InstallPath, "Mods")) || Directory.Exists(Path.Combine(candidate.InstallPath, "mods"))
        };
    }
}
