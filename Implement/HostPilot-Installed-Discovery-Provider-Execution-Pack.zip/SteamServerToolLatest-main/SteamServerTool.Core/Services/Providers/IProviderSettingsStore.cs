using SteamServerTool.Core.Models.Providers;

namespace SteamServerTool.Core.Services.Providers;

public interface IProviderSettingsStore
{
    Task<ProviderSettings> LoadAsync(CancellationToken cancellationToken = default);
    Task SaveAsync(ProviderSettings settings, CancellationToken cancellationToken = default);
}
