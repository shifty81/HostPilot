using System.Collections.ObjectModel;
using SteamServerTool.Core.Models.Discovery;

namespace SteamServerTool.ViewModels;

public sealed class ImportDiscoveredServersViewModel
{
    public ObservableCollection<DiscoveredServerCandidate> Candidates { get; } = new();

    public void Load(IEnumerable<DiscoveredServerCandidate> candidates)
    {
        Candidates.Clear();
        foreach (var candidate in candidates)
        {
            Candidates.Add(candidate);
        }
    }

    public IReadOnlyList<DiscoveredServerCandidate> SelectedForImport()
        => Candidates.Where(x => !x.IsImported).ToList();
}
