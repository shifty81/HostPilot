using System.Windows;
using SteamServerTool.ViewModels;

namespace SteamServerTool.Dialogs;

public partial class ImportDiscoveredServersDialog : Window
{
    public ImportDiscoveredServersDialog(ImportDiscoveredServersViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;
    }

    private void OnImportClicked(object sender, RoutedEventArgs e)
    {
        DialogResult = true;
        Close();
    }
}
