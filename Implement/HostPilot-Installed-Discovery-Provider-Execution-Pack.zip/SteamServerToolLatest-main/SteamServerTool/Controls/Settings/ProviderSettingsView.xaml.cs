using System.Windows.Controls;

namespace SteamServerTool.Controls.Settings;

public partial class ProviderSettingsView : UserControl
{
    public ProviderSettingsView()
    {
        InitializeComponent();
    }
}
