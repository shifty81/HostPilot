# Runtime Automation Pack v16-v18

This pack extends the current SteamServerTool direction with a dedicated runtime automation layer.

## Scope

### v16 — Runtime Event + Trigger Engine
Adds normalized runtime events, rule triggers, condition evaluation, cooldowns, debounce windows, and rule execution records.

### v17 — Action Pipeline + Safety Policies
Adds a strongly-typed action dispatcher for restart, stop, backup, notify, RCON, mod sync, and template application workflows. Includes policy gates so automations cannot perform dangerous actions without explicit approval or environment checks.

### v18 — Scheduling + Workflow Composition
Adds schedules, delayed actions, chained workflows, maintenance windows, and event-driven orchestration for recurring server operations.

## Intended integration points in current repo
- `SteamServerTool.Core/Services/ServerManager.cs`
- `SteamServerTool.Core/Services/RconClient.cs`
- `SteamServerTool.Core/Services/BackupService.cs`
- `SteamServerTool.Core/Services/WorkshopService.cs`
- WPF dashboard / per-server detail popup / notifications center

## What this pack contains
- Architecture notes
- Rule model definitions
- Event bus scaffold
- Automation engine scaffold
- Action dispatcher scaffold
- Safety policy scaffold
- Scheduler scaffold
- ViewModel scaffold
- Test skeletons

## Design goals
- Event-first instead of timer-only automation
- Safe by default
- Provider/game agnostic with per-provider extensions later
- Works for single servers and cluster parents
- Easy to surface in dark-mode WPF UI
- Supports future remote node execution and web control

## Examples this enables
- Restart server if memory exceeds threshold for 10 minutes
- Notify before restart, warn in-game by RCON, wait 60 seconds, then restart
- Auto-backup on clean shutdown
- Run mod sync after Steam Workshop collection change
- Nightly save + backup + log prune workflow
- Cluster-wide rolling restart with per-node health checks

