# Rule Model

## Rule shape
Each rule should define:
- identity
- display metadata
- enabled state
- target scope
- trigger
- conditions
- actions
- cooldown / debounce / suppression
- maintenance policy
- audit metadata

## Trigger examples
- `ProcessExited`
- `CpuThresholdExceeded`
- `MemoryThresholdExceeded`
- `PlayerCountChanged`
- `ScheduledTimeReached`
- `WorkshopItemsUpdated`
- `BackupCompleted`
- `RconHealthCheckFailed`
- `ServerReportedReady`
- `ServerOutputMatched`

## Condition examples
- server is online
- player count is 0
- player count < 5
- memory MB > threshold
- event repeated N times in M minutes
- current time is inside maintenance window
- last backup is younger than X minutes
- config flag is true

## Action examples
- toast notification
- persistent alert
- enqueue backup
- send chat warning over RCON
- save world over RCON
- graceful stop
- forced kill
- restart
- mod sync
- apply template
- set maintenance mode
- webhook / remote node call later

## Suggested UX structure
Per server automation tab:
- Rule list
- Trigger picker
- Condition builder
- Action chain editor
- Maintenance windows
- Execution history
- Dry-run simulator

