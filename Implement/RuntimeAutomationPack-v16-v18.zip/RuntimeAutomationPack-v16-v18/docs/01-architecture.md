# Architecture

## Core flow

1. Runtime emits normalized events.
2. Event bus forwards them to automation engine.
3. Automation engine resolves rules that subscribe to that event type.
4. Conditions are evaluated against current server state, event payload, and rule context.
5. Matching rules are checked for cooldown, maintenance window, and safety policy.
6. Actions are expanded into one or more executable action steps.
7. Action dispatcher executes steps directly or routes them into the existing operation queue.
8. Results are persisted as execution records and surfaced in notification center / automation history.

## Key subsystems

### Runtime event bus
Normalizes events coming from:
- process output parsers
- health probes
- scheduled timers
- install/update pipelines
- mod/platform integrations
- user UI actions
- cluster orchestration state

### Automation engine
Stateless matching + stateful execution guards:
- trigger matching
- condition evaluation
- cooldowns
- debounce windows
- once-per-window suppression
- execution locking

### Action dispatcher
Responsible for converting high-level actions into concrete operations:
- send RCON command
- show notification
- enqueue backup
- restart process
- stop process
- run update
- sync mods
- apply config template

### Policy guard
Safety boundary that can reject or downgrade actions based on:
- server online state
- player count
- maintenance mode
- backup freshness
- protected hours
- cluster parent/child constraints

### Scheduler
Supports:
- cron-like schedules
- fixed interval schedules
- delayed follow-up actions
- quiet hours / maintenance windows

## Recommended persistence
Start with JSON for fastest integration, then move to SQLite if history volume grows.

Suggested files:
- `automation-rules.json`
- `automation-history.json`
- `automation-state.json`

## Cluster behavior
Cluster-aware rules should declare target scope:
- single instance
- cluster parent
- cluster children
- all instances in cluster
- rolling one-at-a-time

