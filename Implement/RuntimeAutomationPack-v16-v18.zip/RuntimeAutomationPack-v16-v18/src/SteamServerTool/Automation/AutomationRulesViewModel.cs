using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using SteamServerTool.Core.Automation.Models;

namespace SteamServerTool.Automation;

public sealed class AutomationRulesViewModel : INotifyPropertyChanged
{
    private AutomationRule? _selectedRule;

    public ObservableCollection<AutomationRule> Rules { get; } = new();

    public AutomationRule? SelectedRule
    {
        get => _selectedRule;
        set
        {
            if (_selectedRule == value)
            {
                return;
            }

            _selectedRule = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
