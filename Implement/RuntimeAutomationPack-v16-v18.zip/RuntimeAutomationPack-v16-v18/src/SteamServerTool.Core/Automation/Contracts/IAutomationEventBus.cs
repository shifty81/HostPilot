using System;
using System.Threading;
using System.Threading.Tasks;
using SteamServerTool.Core.Automation.Models;

namespace SteamServerTool.Core.Automation.Contracts;

public interface IAutomationEventBus
{
    event EventHandler<RuntimeEvent>? EventPublished;
    Task PublishAsync(RuntimeEvent runtimeEvent, CancellationToken cancellationToken = default);
}
