using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using SteamServerTool.Core.Automation.Models;

namespace SteamServerTool.Core.Automation.Contracts;

public interface IAutomationRuleStore
{
    Task<IReadOnlyList<AutomationRule>> GetRulesAsync(CancellationToken cancellationToken = default);
    Task SaveRulesAsync(IReadOnlyList<AutomationRule> rules, CancellationToken cancellationToken = default);
    Task AppendExecutionAsync(AutomationExecutionRecord record, CancellationToken cancellationToken = default);
}
