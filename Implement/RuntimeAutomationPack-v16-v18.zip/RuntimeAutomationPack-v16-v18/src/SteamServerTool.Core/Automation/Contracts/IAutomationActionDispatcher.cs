using System.Threading;
using System.Threading.Tasks;
using SteamServerTool.Core.Automation.Models;

namespace SteamServerTool.Core.Automation.Contracts;

public interface IAutomationActionDispatcher
{
    Task<AutomationActionResult> DispatchAsync(
        AutomationRule rule,
        AutomationAction action,
        RuntimeEvent runtimeEvent,
        CancellationToken cancellationToken = default);
}
