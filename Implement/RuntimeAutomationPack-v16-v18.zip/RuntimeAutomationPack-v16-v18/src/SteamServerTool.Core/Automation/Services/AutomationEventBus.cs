using System;
using System.Threading;
using System.Threading.Tasks;
using SteamServerTool.Core.Automation.Contracts;
using SteamServerTool.Core.Automation.Models;

namespace SteamServerTool.Core.Automation.Services;

public sealed class AutomationEventBus : IAutomationEventBus
{
    public event EventHandler<RuntimeEvent>? EventPublished;

    public Task PublishAsync(RuntimeEvent runtimeEvent, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        EventPublished?.Invoke(this, runtimeEvent);
        return Task.CompletedTask;
    }
}
