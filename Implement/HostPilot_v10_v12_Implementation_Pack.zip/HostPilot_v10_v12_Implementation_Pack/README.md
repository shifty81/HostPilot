# HostPilot / Steam Server Admin — Full v10–v12 Implementation Pack

This pack extends the existing WPF-based server admin application with three major layers:

- **v10**: Remote node agents + web control
- **v11**: Mod platform integrations (Steam Workshop, CurseForge, Modrinth, Vintage Story, local zip/folder intake)
- **v12**: Marketplace / templates / sharing

The files in this pack are structured as a **compile-oriented scaffold**:
- concrete contracts
- concrete service boundaries
- starter implementations
- API surfaces
- WPF integration seams
- docs for wiring into the current solution

## Target outcomes

### v10
- manage many remote machines from one desktop app
- install a lightweight agent on nodes
- secure node registration with tokens
- poll/dispatch operations
- stream logs and heartbeats
- expose a local/lan web control surface

### v11
- unify mod sources under one abstraction
- add dependency resolution pipeline
- support imports from workshop/platforms/local zip/folder
- maintain deployment-specific mod manifests and install state

### v12
- create reusable deployment templates
- export/import signed template bundles
- share templates between local machines or later cloud services
- add a small marketplace-ready contract surface without forcing cloud dependency now

## Pack layout

- `docs/` — implementation guidance
- `src/SteamServerTool.Core.Additions/` — models and services to merge into existing core
- `src/SteamServerTool.Agent/` — remote node agent service scaffold
- `src/SteamServerTool.Web/` — ASP.NET Core web control + SignalR scaffold
- `src/SteamServerTool.Wpf.Additions/` — WPF integration seam files
- `tests/` — initial test skeletons

## Merge strategy

1. Merge `SteamServerTool.Core.Additions` files into the existing `SteamServerTool.Core` project.
2. Add `SteamServerTool.Agent` and `SteamServerTool.Web` as new projects to the solution.
3. Add the WPF integration seam files to the desktop app project.
4. Register the new services in composition root / App startup.
5. Incrementally wire the existing operation queue, SteamCMD runner, workshop browser, and provider manifests into these abstractions.

This pack is designed to **fit the current standalone server admin project** and does **not** assume Atlas or the game tooling.
