using Microsoft.AspNetCore.Mvc;
using SteamServerTool.Core.Services.Templates;

namespace SteamServerTool.Web.Controllers;

[ApiController]
[Route("api/marketplace")]
public sealed class MarketplaceController : ControllerBase
{
    private readonly ITemplateLibraryService _templateLibraryService;

    public MarketplaceController(ITemplateLibraryService templateLibraryService)
    {
        _templateLibraryService = templateLibraryService;
    }

    [HttpGet("featured")]
    public async Task<IActionResult> GetFeatured(CancellationToken cancellationToken)
    {
        var all = await _templateLibraryService.GetAllAsync(cancellationToken);
        var featured = all.Take(12).Select(x => new
        {
            x.Id,
            x.DisplayName,
            x.Description,
            x.GameId,
            x.ProviderId,
            x.Version,
            x.Author,
            x.Tags
        });

        return Ok(featured);
    }
}
