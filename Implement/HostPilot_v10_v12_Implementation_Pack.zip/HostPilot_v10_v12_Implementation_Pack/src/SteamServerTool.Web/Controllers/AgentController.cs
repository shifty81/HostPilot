using Microsoft.AspNetCore.Mvc;
using SteamServerTool.Core.Models.Nodes;
using SteamServerTool.Core.Services.Nodes;

namespace SteamServerTool.Web.Controllers;

[ApiController]
[Route("api/agent")]
public sealed class AgentController : ControllerBase
{
    private readonly INodeRegistryService _nodeRegistryService;
    private readonly INodeEnrollmentService _nodeEnrollmentService;
    private readonly INodeCommandQueue _nodeCommandQueue;

    public AgentController(
        INodeRegistryService nodeRegistryService,
        INodeEnrollmentService nodeEnrollmentService,
        INodeCommandQueue nodeCommandQueue)
    {
        _nodeRegistryService = nodeRegistryService;
        _nodeEnrollmentService = nodeEnrollmentService;
        _nodeCommandQueue = nodeCommandQueue;
    }

    [HttpPost("enroll")]
    public async Task<IActionResult> Enroll([FromBody] EnrollRequest request, CancellationToken cancellationToken)
    {
        var ok = await _nodeEnrollmentService.ValidateAndConsumeTokenAsync(request.NodeId, request.Token, cancellationToken);
        if (!ok)
        {
            return Unauthorized();
        }

        var existing = await _nodeRegistryService.GetAsync(request.NodeId, cancellationToken)
            ?? new ManagedNode
            {
                Id = request.NodeId,
                DisplayName = $"Node-{request.NodeId.ToString()[..8]}",
                Hostname = request.NodeId.ToString()
            };

        await _nodeRegistryService.UpsertAsync(existing, cancellationToken);
        return Ok(new { ok = true });
    }

    [HttpPost("heartbeat")]
    public async Task<IActionResult> Heartbeat([FromBody] NodeHeartbeat heartbeat, CancellationToken cancellationToken)
    {
        await _nodeRegistryService.UpdateHeartbeatAsync(heartbeat, cancellationToken);
        return Ok(new { ok = true });
    }

    [HttpGet("commands/{nodeId:guid}")]
    public async Task<IReadOnlyList<NodeCommandEnvelope>> GetCommands(Guid nodeId, CancellationToken cancellationToken)
        => await _nodeCommandQueue.DequeuePendingAsync(nodeId, 20, cancellationToken);

    [HttpPost("commands/{commandId:guid}/complete")]
    public async Task<IActionResult> Complete(Guid commandId, [FromBody] object result, CancellationToken cancellationToken)
    {
        await _nodeCommandQueue.CompleteAsync(commandId, System.Text.Json.JsonSerializer.Serialize(result), cancellationToken);
        return Ok(new { ok = true });
    }

    [HttpPost("commands/{commandId:guid}/fail")]
    public async Task<IActionResult> Fail(Guid commandId, [FromBody] FailRequest request, CancellationToken cancellationToken)
    {
        await _nodeCommandQueue.FailAsync(commandId, request.Error, cancellationToken);
        return Ok(new { ok = true });
    }

    public sealed class EnrollRequest
    {
        public Guid NodeId { get; set; }
        public string Token { get; set; } = string.Empty;
    }

    public sealed class FailRequest
    {
        public string Error { get; set; } = string.Empty;
    }
}
