using Microsoft.AspNetCore.Mvc;
using SteamServerTool.Core.Models.Templates;
using SteamServerTool.Core.Services.Templates;

namespace SteamServerTool.Web.Controllers;

[ApiController]
[Route("api/templates")]
public sealed class TemplatesController : ControllerBase
{
    private readonly ITemplateLibraryService _templateLibraryService;

    public TemplatesController(ITemplateLibraryService templateLibraryService)
    {
        _templateLibraryService = templateLibraryService;
    }

    [HttpGet]
    public Task<IReadOnlyList<DeploymentTemplateBundle>> GetAll(CancellationToken cancellationToken)
        => _templateLibraryService.GetAllAsync(cancellationToken);

    [HttpPost]
    public Task<DeploymentTemplateBundle> Save([FromBody] DeploymentTemplateBundle bundle, CancellationToken cancellationToken)
        => _templateLibraryService.SaveAsync(bundle, cancellationToken);

    [HttpPost("review")]
    public Task<TemplateReviewResult> Review([FromBody] DeploymentTemplateBundle bundle, CancellationToken cancellationToken)
        => _templateLibraryService.ReviewAsync(bundle, cancellationToken);

    [HttpPost("{id:guid}/export")]
    public Task<string> Export(Guid id, CancellationToken cancellationToken)
    {
        var exportDir = Path.Combine(AppContext.BaseDirectory, "Exports");
        return _templateLibraryService.ExportAsync(id, exportDir, cancellationToken);
    }
}
