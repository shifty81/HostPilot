using Microsoft.AspNetCore.Mvc;
using SteamServerTool.Core.Models.Mods;
using SteamServerTool.Core.Services.Mods;

namespace SteamServerTool.Web.Controllers;

[ApiController]
[Route("api/mods")]
public sealed class ModsController : ControllerBase
{
    private readonly IModCatalogService _modCatalogService;

    public ModsController(IModCatalogService modCatalogService)
    {
        _modCatalogService = modCatalogService;
    }

    [HttpPost("search")]
    public Task<IReadOnlyList<ModPackage>> Search([FromBody] ModSearchQuery query, CancellationToken cancellationToken)
        => _modCatalogService.SearchAsync(query, cancellationToken);

    [HttpPost("import-local")]
    public Task<IReadOnlyList<ModPackage>> ImportLocal([FromBody] LocalModImportRequest request, CancellationToken cancellationToken)
        => _modCatalogService.ImportLocalAsync(request, cancellationToken);
}
