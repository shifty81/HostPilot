using Microsoft.AspNetCore.Mvc;
using SteamServerTool.Core.Models.Nodes;
using SteamServerTool.Core.Services.Nodes;

namespace SteamServerTool.Web.Controllers;

[ApiController]
[Route("api/nodes")]
public sealed class NodesController : ControllerBase
{
    private readonly INodeRegistryService _nodeRegistryService;
    private readonly INodeEnrollmentService _nodeEnrollmentService;
    private readonly INodeCommandQueue _nodeCommandQueue;

    public NodesController(
        INodeRegistryService nodeRegistryService,
        INodeEnrollmentService nodeEnrollmentService,
        INodeCommandQueue nodeCommandQueue)
    {
        _nodeRegistryService = nodeRegistryService;
        _nodeEnrollmentService = nodeEnrollmentService;
        _nodeCommandQueue = nodeCommandQueue;
    }

    [HttpGet]
    public Task<IReadOnlyList<ManagedNode>> GetAll(CancellationToken cancellationToken)
        => _nodeRegistryService.GetAllAsync(cancellationToken);

    [HttpPost]
    public Task<ManagedNode> Upsert([FromBody] ManagedNode node, CancellationToken cancellationToken)
        => _nodeRegistryService.UpsertAsync(node, cancellationToken);

    [HttpPost("{nodeId:guid}/enrollment-token")]
    public Task<NodeEnrollmentToken> CreateToken(Guid nodeId, CancellationToken cancellationToken)
        => _nodeEnrollmentService.CreateEnrollmentTokenAsync(nodeId, TimeSpan.FromMinutes(20), cancellationToken);

    [HttpPost("{nodeId:guid}/commands")]
    public Task<NodeCommandEnvelope> Enqueue(Guid nodeId, [FromBody] NodeCommandEnvelope command, CancellationToken cancellationToken)
    {
        command.NodeId = nodeId;
        return _nodeCommandQueue.EnqueueAsync(command, cancellationToken);
    }
}
