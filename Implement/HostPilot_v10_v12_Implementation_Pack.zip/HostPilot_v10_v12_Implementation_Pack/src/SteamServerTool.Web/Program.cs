using SteamServerTool.Core.Services.Mods;
using SteamServerTool.Core.Services.Nodes;
using SteamServerTool.Core.Services.Templates;
using SteamServerTool.Web.Hubs;

var builder = WebApplication.CreateBuilder(args);

var dataRoot = Path.Combine(AppContext.BaseDirectory, "Data");
Directory.CreateDirectory(dataRoot);

builder.Services.AddSingleton<INodeRegistryService>(_ => new FileNodeRegistryService(Path.Combine(dataRoot, "nodes.json")));
builder.Services.AddSingleton<INodeEnrollmentService>(_ => new FileNodeEnrollmentService(Path.Combine(dataRoot, "node_enrollment.json")));
builder.Services.AddSingleton<INodeCommandQueue, InMemoryNodeCommandQueue>();

builder.Services.AddSingleton<IModProvider, SteamWorkshopProvider>();
builder.Services.AddSingleton<IModProvider, CurseForgeProvider>();
builder.Services.AddSingleton<IModProvider, ModrinthProvider>();
builder.Services.AddSingleton<IModProvider, VintageStoryModProvider>();
builder.Services.AddSingleton<IModCatalogService, ModCatalogService>();

builder.Services.AddSingleton<ITemplateLibraryService>(_ => new FileTemplateLibraryService(Path.Combine(dataRoot, "templates")));

builder.Services.AddSignalR();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials()
              .SetIsOriginAllowed(_ => true));
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseCors();
app.MapControllers();
app.MapHub<NodeHub>("/hubs/nodes");

app.Run();
