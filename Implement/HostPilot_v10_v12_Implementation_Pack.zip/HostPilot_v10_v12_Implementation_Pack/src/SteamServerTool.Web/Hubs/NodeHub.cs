using Microsoft.AspNetCore.SignalR;

namespace SteamServerTool.Web.Hubs;

public sealed class NodeHub : Hub
{
    public Task SubscribeNode(string nodeId)
        => Groups.AddToGroupAsync(Context.ConnectionId, $"node:{nodeId}");
}
