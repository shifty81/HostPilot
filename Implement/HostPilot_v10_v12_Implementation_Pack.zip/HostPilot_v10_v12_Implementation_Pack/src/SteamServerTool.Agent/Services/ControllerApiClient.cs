using System.Net.Http.Json;
using Microsoft.Extensions.Options;
using SteamServerTool.Core.Models.Nodes;

namespace SteamServerTool.Agent.Services;

public sealed class ControllerApiClient
{
    private readonly HttpClient _httpClient = new();
    private readonly AgentSettings _settings;
    private bool _enrolled;

    public ControllerApiClient(IOptions<AgentSettings> settings)
    {
        _settings = settings.Value;
        _httpClient.BaseAddress = new Uri(_settings.ControllerBaseUrl);
    }

    public async Task EnsureEnrolledAsync(CancellationToken cancellationToken)
    {
        if (_enrolled)
        {
            return;
        }

        var response = await _httpClient.PostAsJsonAsync("/api/agent/enroll", new
        {
            nodeId = _settings.NodeId,
            token = _settings.EnrollmentToken
        }, cancellationToken);

        response.EnsureSuccessStatusCode();
        _enrolled = true;
    }

    public async Task SendHeartbeatAsync(NodeHeartbeat heartbeat, CancellationToken cancellationToken)
    {
        await EnsureEnrolledAsync(cancellationToken);
        var response = await _httpClient.PostAsJsonAsync("/api/agent/heartbeat", heartbeat, cancellationToken);
        response.EnsureSuccessStatusCode();
    }

    public async Task<IReadOnlyList<NodeCommandEnvelope>> PollCommandsAsync(CancellationToken cancellationToken)
    {
        await EnsureEnrolledAsync(cancellationToken);
        return await _httpClient.GetFromJsonAsync<List<NodeCommandEnvelope>>($"/api/agent/commands/{_settings.NodeId}", cancellationToken)
            ?? new List<NodeCommandEnvelope>();
    }

    public async Task CompleteCommandAsync(Guid commandId, object result, CancellationToken cancellationToken)
    {
        var response = await _httpClient.PostAsJsonAsync($"/api/agent/commands/{commandId}/complete", result, cancellationToken);
        response.EnsureSuccessStatusCode();
    }

    public async Task FailCommandAsync(Guid commandId, string error, CancellationToken cancellationToken)
    {
        var response = await _httpClient.PostAsJsonAsync($"/api/agent/commands/{commandId}/fail", new { error }, cancellationToken);
        response.EnsureSuccessStatusCode();
    }
}
