using Microsoft.Extensions.Options;

namespace SteamServerTool.Agent.Services;

public sealed class AgentCommandPollService : BackgroundService
{
    private readonly ControllerApiClient _controllerApiClient;
    private readonly AgentSettings _settings;
    private readonly ILogger<AgentCommandPollService> _logger;

    public AgentCommandPollService(
        ControllerApiClient controllerApiClient,
        IOptions<AgentSettings> settings,
        ILogger<AgentCommandPollService> logger)
    {
        _controllerApiClient = controllerApiClient;
        _settings = settings.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var commands = await _controllerApiClient.PollCommandsAsync(stoppingToken);
                foreach (var command in commands)
                {
                    try
                    {
                        _logger.LogInformation("Executing command {CommandId} ({Type})", command.CommandId, command.CommandType);

                        // Replace this switch with real provider/operation queue wiring.
                        object result = command.CommandType switch
                        {
                            "ping" => new { ok = true, utc = DateTimeOffset.UtcNow },
                            _ => new { ok = true, handled = false, type = command.CommandType }
                        };

                        await _controllerApiClient.CompleteCommandAsync(command.CommandId, result, stoppingToken);
                    }
                    catch (Exception ex)
                    {
                        await _controllerApiClient.FailCommandAsync(command.CommandId, ex.Message, stoppingToken);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Command poll failed.");
            }

            await Task.Delay(TimeSpan.FromSeconds(_settings.CommandPollSeconds), stoppingToken);
        }
    }
}
