using Microsoft.Extensions.Options;
using SteamServerTool.Core.Models.Nodes;

namespace SteamServerTool.Agent.Services;

public sealed class AgentHeartbeatService : BackgroundService
{
    private readonly ControllerApiClient _controllerApiClient;
    private readonly AgentSettings _settings;
    private readonly ILogger<AgentHeartbeatService> _logger;

    public AgentHeartbeatService(
        ControllerApiClient controllerApiClient,
        IOptions<AgentSettings> settings,
        ILogger<AgentHeartbeatService> logger)
    {
        _controllerApiClient = controllerApiClient;
        _settings = settings.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var heartbeat = new NodeHeartbeat
                {
                    NodeId = _settings.NodeId,
                    AgentVersion = _settings.AgentVersion,
                    CpuPercent = Random.Shared.Next(0, 100),
                    MemoryUsedMb = 2048,
                    MemoryTotalMb = 8192,
                    RunningServerCount = 0,
                    Status = "Online"
                };

                await _controllerApiClient.SendHeartbeatAsync(heartbeat, stoppingToken);
                _logger.LogInformation("Heartbeat sent for node {NodeId}", _settings.NodeId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to send heartbeat.");
            }

            await Task.Delay(TimeSpan.FromSeconds(_settings.HeartbeatSeconds), stoppingToken);
        }
    }
}
