namespace SteamServerTool.Agent;

public sealed class AgentSettings
{
    public Guid NodeId { get; set; }
    public string ControllerBaseUrl { get; set; } = "http://127.0.0.1:5188";
    public string EnrollmentToken { get; set; } = string.Empty;
    public string AgentVersion { get; set; } = "0.1.0";
    public int HeartbeatSeconds { get; set; } = 20;
    public int CommandPollSeconds { get; set; } = 5;
}
