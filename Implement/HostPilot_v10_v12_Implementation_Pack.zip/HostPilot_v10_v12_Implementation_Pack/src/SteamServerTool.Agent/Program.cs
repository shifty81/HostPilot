using SteamServerTool.Agent;
using SteamServerTool.Agent.Services;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.Configure<AgentSettings>(builder.Configuration.GetSection("Agent"));
builder.Services.AddSingleton<ControllerApiClient>();
builder.Services.AddHostedService<AgentHeartbeatService>();
builder.Services.AddHostedService<AgentCommandPollService>();

var host = builder.Build();
host.Run();
