using System.Collections.ObjectModel;
using System.Net.Http.Json;
using SteamServerTool.Core.Models.Nodes;

namespace SteamServerTool.Wpf.Additions.ViewModels;

public sealed class NodesViewModel
{
    private readonly HttpClient _httpClient;

    public NodesViewModel(string baseUrl)
    {
        _httpClient = new HttpClient { BaseAddress = new Uri(baseUrl) };
    }

    public ObservableCollection<ManagedNode> Nodes { get; } = new();

    public async Task RefreshAsync(CancellationToken cancellationToken = default)
    {
        var nodes = await _httpClient.GetFromJsonAsync<List<ManagedNode>>("/api/nodes", cancellationToken)
            ?? new List<ManagedNode>();

        Nodes.Clear();
        foreach (var node in nodes.OrderBy(x => x.DisplayName))
        {
            Nodes.Add(node);
        }
    }

    public async Task<string> CreateEnrollmentTokenAsync(Guid nodeId, CancellationToken cancellationToken = default)
    {
        var token = await _httpClient.PostAsJsonAsync($"/api/nodes/{nodeId}/enrollment-token", new { }, cancellationToken);
        token.EnsureSuccessStatusCode();
        var data = await token.Content.ReadFromJsonAsync<NodeEnrollmentToken>(cancellationToken: cancellationToken);
        return data?.Token ?? string.Empty;
    }
}
