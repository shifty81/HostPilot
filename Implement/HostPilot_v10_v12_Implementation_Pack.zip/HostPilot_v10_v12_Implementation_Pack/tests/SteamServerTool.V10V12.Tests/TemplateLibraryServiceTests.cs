using SteamServerTool.Core.Models.Templates;
using SteamServerTool.Core.Services.Templates;

namespace SteamServerTool.V10V12.Tests;

public sealed class TemplateLibraryServiceTests
{
    [Fact]
    public async Task Save_And_List_Template_Works()
    {
        var dir = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N"));
        var service = new FileTemplateLibraryService(dir);

        await service.SaveAsync(new DeploymentTemplateBundle
        {
            DisplayName = "Test Template",
            Slug = "test-template",
            GameId = "rust",
            ProviderId = "steamcmd"
        });

        var all = await service.GetAllAsync();
        Assert.Single(all);
    }
}
