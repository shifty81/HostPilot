# Integration Steps

## 1) Add projects to solution
Add:
- `SteamServerTool.Agent`
- `SteamServerTool.Web`

## 2) Merge core additions
Copy the files from `src/SteamServerTool.Core.Additions/` into your existing `SteamServerTool.Core` project.

## 3) Register services in desktop app
At startup, register:
- node registry service
- agent enrollment service
- mod catalog coordinator
- template library service
- web host coordinator

## 4) Start web host from desktop app
The desktop app should be able to launch/stop the embedded web host:
- default bind: `http://127.0.0.1:5188`
- optional LAN bind via setting
- protect with admin auth

## 5) Wire operation queue
Replace direct local-only execution assumptions with:
- local execution path
- remote node execution path

Both should enqueue through common operation models.

## 6) Wire mod browser
The existing workshop browser becomes one provider implementation.
The mod tab then calls `IModCatalogService` instead of a provider-specific service directly.

## 7) Wire templates
Existing server templates can be normalized into the new sharable template bundle model.

## 8) Add persistence
Persist these stores:
- nodes.json
- node_enrollment.json
- mods_catalog_cache.json
- deployment_mods.json
- templates_library.json

## 9) Immediate next pass after merge
- service installer for agent
- real provider API clients
- auth hardening
- signature validation
- dependency solver refinement
