# v11 — Mod Platform Integrations

## Goal

Create a single mod pipeline that can ingest content from:

- Steam Workshop
- CurseForge
- Modrinth
- Vintage Story Mod DB / website feed
- Local zip files
- Local folders
- Manual URL packages later

## Unified lifecycle

1. Search / discover package
2. Read metadata
3. Resolve dependencies
4. Download or import
5. Validate compatibility against deployment/provider/game/version
6. Install into staging
7. Activate into server instance
8. Record state in deployment mod manifest
9. Detect drift on next refresh

## Why this matters

Right now the project already has workshop-oriented logic. v11 lifts that into a generic provider model so the mod tab becomes:
- provider aware
- dependency aware
- deployment aware
- import aware
- rollback capable

## Local intake rules

Local drag-and-drop should support:
- zip file
- folder
- multiple files
- multiple folders

For each intake:
- hash package
- inspect manifest if available
- normalize into internal package metadata
- place raw source in cache/archive
- install to provider-specific managed storage
- update deployment manifest

## Compatibility decision matrix

The UI should classify each mod as:
- compatible
- warning
- blocked
- unknown

Based on:
- game id
- server version
- loader/framework
- dependencies
- conflicts
- side type (server/client/both)
- provider metadata quality

## Recommended UI tabs inside Mods

- Browse
- Installed
- Dependencies
- Import Local
- Conflicts
- Updates
- Provider Settings
