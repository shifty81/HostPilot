# v12 — Marketplace / Templates / Sharing

## Scope

This version does **not** require a public internet marketplace on day one.
It creates the internal architecture so local/library/community sharing can evolve into that later.

## Template bundle contents

A template bundle can contain:
- deployment manifest
- provider/game id
- server config fields
- startup args
- install channels
- mod manifest references
- optional screenshots or thumbnail
- author metadata
- version metadata
- capability tags
- export signature / checksum
- optional readme/license

## Three levels of sharing

### Level 1 — Local Library
User saves templates to local repository:
- private
- fast
- no external service required

### Level 2 — File Export / Import
User exports `.hostpilot-template.zip`:
- send to friends/team
- import from file into library
- verify checksum/signature
- review before apply

### Level 3 — Marketplace-ready Service Layer
A future web service can expose:
- searchable template catalog
- ratings/download counts
- author profiles
- moderation status
- version channels

This pack includes the contracts and local service boundaries needed for that later step.

## Review model before apply

Imported/shared templates should open a review wizard showing:
- game/provider
- ports
- storage paths
- mods included
- secrets required
- unsupported fields
- conflicts with local policies
- trust level
