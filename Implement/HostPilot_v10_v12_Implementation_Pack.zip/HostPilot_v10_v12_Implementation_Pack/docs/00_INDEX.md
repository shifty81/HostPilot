# v10–v12 Index

## v10 — Remote node agents + web control
- `docs/V10_REMOTE_NODE_AGENTS.md`
- `src/SteamServerTool.Agent/`
- `src/SteamServerTool.Web/`
- `src/SteamServerTool.Core.Additions/Models/Nodes/*`
- `src/SteamServerTool.Core.Additions/Services/Nodes/*`

## v11 — Mod platform integrations
- `docs/V11_MOD_PLATFORM_INTEGRATIONS.md`
- `src/SteamServerTool.Core.Additions/Models/Mods/*`
- `src/SteamServerTool.Core.Additions/Services/Mods/*`

## v12 — Marketplace / templates / sharing
- `docs/V12_MARKETPLACE_TEMPLATES_SHARING.md`
- `src/SteamServerTool.Core.Additions/Models/Templates/*`
- `src/SteamServerTool.Core.Additions/Services/Templates/*`
- `src/SteamServerTool.Web/Controllers/TemplatesController.cs`
- `src/SteamServerTool.Web/Controllers/MarketplaceController.cs`

## Integration / composition
- `docs/INTEGRATION_STEPS.md`
- `src/SteamServerTool.Wpf.Additions/ViewModels/*`
