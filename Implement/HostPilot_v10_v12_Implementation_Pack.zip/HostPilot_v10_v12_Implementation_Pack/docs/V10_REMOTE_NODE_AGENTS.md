# v10 — Remote Node Agents + Web Control

## What this adds

The current application is strongest as a **single-machine desktop manager**. v10 turns it into a **controller + agent mesh**.

### Controller side
The controller is the existing WPF desktop app plus an ASP.NET Core web host:
- keeps node registry
- issues deployment/start/stop/update operations
- streams logs/status
- exposes browser-based dashboards over local network or reverse proxy later

### Agent side
Each managed machine runs a lightweight background service:
- registers using bootstrap token
- polls for commands
- reports capabilities and inventory
- executes local operations
- pushes logs, metrics, and heartbeat state

## Core flow

1. User adds a node in WPF.
2. Controller generates one-time enrollment token.
3. Agent installs on remote machine.
4. Agent uses token to register and obtain persistent node credentials.
5. Agent begins:
   - heartbeat loop
   - command poll loop
   - log upload / stream
   - inventory refresh
6. WPF and web UI both display node state from the same controller APIs.

## Security minimums

- bootstrap token: one-time, short-lived
- persistent node secret rotated after enrollment
- HMAC signing for agent requests
- TLS strongly recommended for non-localhost usage
- role-based web access for browser control
- operation audit log for every remote action

## Recommended next hardening pass after merge

- Windows service installer
- service recovery configuration
- secret encryption with DPAPI / machine store
- signed agent packages
- WebAuthn or TOTP for admin web sessions
- command nonce / replay protection
- per-node permissions / tags / maintenance windows

## Important implementation rule

The agent should **not contain server-specific business logic directly** beyond execution orchestration.
Game/provider-specific behavior should stay in provider adapters and shared operation handlers where possible.
