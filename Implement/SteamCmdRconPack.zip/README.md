# SteamCMD Runner + Stdout Parser + Graceful Shutdown/RCON Supervision Pack

This pack is a repo-ready WPF scaffold for a Windows server admin app.

## Included
- Real `ProcessStartInfo`-based SteamCMD launch flow
- Streaming stdout/stderr pump
- SteamCMD output parser with progress classification
- Source-style TCP RCON packet client
- Server process supervision
- Graceful stop flow: RCON quit -> wait -> forced kill after timeout
- Simple WPF dashboard for profile editing, logs, and RCON testing

## Important notes
- The RCON client is implemented for the common Source packet format. Some games need a different protocol or additional quirks.
- `CloseMainWindow()` is not a true console Ctrl+C replacement. For many dedicated servers, RCON is the proper graceful stop path.
- SteamCMD output varies by game and by SteamCMD version. Extend `SteamCmdOutputParser` with your exact patterns.
- For production, store Steam credentials securely and do not bind plaintext passwords directly in UI.

## Core files
- `Services/SteamCmdRunner.cs`
- `Services/SteamCmdOutputParser.cs`
- `Services/RconClient.cs`
- `Services/ServerProcessSupervisor.cs`
- `Services/SteamServerCoordinator.cs`
- `ViewModels/MainWindowViewModel.cs`

## Good next expansions
- SteamGuard / login challenge workflow UI
- Per-provider stdout parsers
- Better server stop strategies per title
- Restart policy / crash loop guard
- Operation queue integration
- Profile encryption for secrets
