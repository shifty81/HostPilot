using System.Windows;

namespace SteamCmdRconPack;

public partial class App : Application
{
}
