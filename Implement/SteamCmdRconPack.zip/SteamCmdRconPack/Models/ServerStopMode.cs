namespace SteamCmdRconPack.Models;

public enum ServerStopMode
{
    RconQuit,
    CtrlC,
    KillAfterTimeout
}
