namespace SteamCmdRconPack.Models;

public sealed class RconResponse
{
    public bool Succeeded { get; set; }
    public string ResponseText { get; set; } = string.Empty;
    public string Summary { get; set; } = string.Empty;
}
