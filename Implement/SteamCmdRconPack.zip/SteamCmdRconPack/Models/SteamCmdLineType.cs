namespace SteamCmdRconPack.Models;

public enum SteamCmdLineType
{
    Info,
    Warning,
    Error,
    Progress,
    Success,
    Unknown
}
