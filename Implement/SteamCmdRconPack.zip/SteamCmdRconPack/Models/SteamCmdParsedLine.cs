namespace SteamCmdRconPack.Models;

public sealed class SteamCmdParsedLine
{
    public SteamCmdLineType LineType { get; set; } = SteamCmdLineType.Unknown;
    public string RawLine { get; set; } = string.Empty;
    public string? EventKey { get; set; }
    public int? Percent { get; set; }
    public string? StatusText { get; set; }
    public bool IsTerminalFailure { get; set; }
    public bool IsTerminalSuccess { get; set; }
}
