namespace SteamCmdRconPack.Models;

public sealed class SteamCmdRunResult
{
    public bool Succeeded { get; set; }
    public int ExitCode { get; set; }
    public string Summary { get; set; } = string.Empty;
}
