namespace SteamCmdRconPack.Models;

public sealed class SteamCmdProfile
{
    public string ProfileName { get; set; } = "Sample Source Server";
    public string SteamCmdPath { get; set; } = @"C:\Tools\steamcmd\steamcmd.exe";
    public string InstallDirectory { get; set; } = @"C:\Servers\SampleSource";
    public string AppId { get; set; } = "232330";
    public string Branch { get; set; } = "public";
    public bool ValidateFiles { get; set; }
    public string Username { get; set; } = "anonymous";
    public string Password { get; set; } = "";
    public string? SteamGuardCode { get; set; }
    public string? ServerExePath { get; set; } = @"C:\Servers\SampleSource\srcds.exe";
    public string ServerArguments { get; set; } = "-console -game cstrike +map de_dust2 -port 27015";
    public string Host { get; set; } = "127.0.0.1";
    public int GamePort { get; set; } = 27015;
    public int RconPort { get; set; } = 27015;
    public string RconPassword { get; set; } = "changeme";
    public int StopTimeoutSeconds { get; set; } = 25;
}
