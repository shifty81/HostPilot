namespace SteamCmdRconPack.Models;

public enum SteamCmdJobKind
{
    Install,
    Update,
    Validate
}
