using System;

namespace SteamCmdRconPack.Models;

public sealed class LogEntry
{
    public DateTime TimestampUtc { get; set; } = DateTime.UtcNow;
    public string Source { get; set; } = "System";
    public SteamCmdLineType LineType { get; set; } = SteamCmdLineType.Info;
    public string Message { get; set; } = string.Empty;
}
