using System.Windows;
using SteamCmdRconPack.ViewModels;

namespace SteamCmdRconPack;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainWindowViewModel();
    }
}
