using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using SteamCmdRconPack.Commands;
using SteamCmdRconPack.Models;
using SteamCmdRconPack.Services;

namespace SteamCmdRconPack.ViewModels;

public sealed class MainWindowViewModel : ViewModelBase
{
    private readonly SteamServerCoordinator _coordinator = new();
    private CancellationTokenSource? _cts;
    private int _progressPercent;
    private string _statusText = "Idle";
    private string _rconCommand = "status";
    private string _rconResponse = string.Empty;

    public SteamCmdProfile Profile { get; } = new();
    public ObservableCollection<LogEntry> Logs { get; } = new();

    public int ProgressPercent
    {
        get => _progressPercent;
        set => SetProperty(ref _progressPercent, value);
    }

    public string StatusText
    {
        get => _statusText;
        set => SetProperty(ref _statusText, value);
    }

    public string RconCommand
    {
        get => _rconCommand;
        set => SetProperty(ref _rconCommand, value);
    }

    public string RconResponse
    {
        get => _rconResponse;
        set => SetProperty(ref _rconResponse, value);
    }

    public bool IsServerRunning => _coordinator.State.IsRunning;
    public string ServerStateText => _coordinator.State.StatusText;

    public ICommand InstallCommand { get; }
    public ICommand UpdateCommand { get; }
    public ICommand ValidateCommand { get; }
    public ICommand StartServerCommand { get; }
    public ICommand StopServerCommand { get; }
    public ICommand SendRconCommand { get; }
    public ICommand CancelCommand { get; }

    public MainWindowViewModel()
    {
        InstallCommand = new RelayCommand(async _ => await RunSteamCmdAsync(SteamCmdJobKind.Install));
        UpdateCommand = new RelayCommand(async _ => await RunSteamCmdAsync(SteamCmdJobKind.Update));
        ValidateCommand = new RelayCommand(async _ => await RunSteamCmdAsync(SteamCmdJobKind.Validate));
        StartServerCommand = new RelayCommand(async _ => await StartServerAsync());
        StopServerCommand = new RelayCommand(async _ => await StopServerAsync());
        SendRconCommand = new RelayCommand(async _ => await SendRconAsync());
        CancelCommand = new RelayCommand(_ => _cts?.Cancel());

        AddLog(new LogEntry { Source = "System", LineType = SteamCmdLineType.Info, Message = "Ready." });
    }

    private async Task RunSteamCmdAsync(SteamCmdJobKind kind)
    {
        _cts?.Cancel();
        _cts = new CancellationTokenSource();
        ProgressPercent = 0;
        StatusText = $"Running {kind}...";

        var result = kind switch
        {
            SteamCmdJobKind.Install => await _coordinator.InstallAsync(Profile, AddLog, UpdateProgress, _cts.Token),
            SteamCmdJobKind.Update => await _coordinator.UpdateAsync(Profile, AddLog, UpdateProgress, _cts.Token),
            _ => await _coordinator.ValidateAsync(Profile, AddLog, UpdateProgress, _cts.Token)
        };

        StatusText = result.Summary;
    }

    private async Task StartServerAsync()
    {
        _cts?.Cancel();
        _cts = new CancellationTokenSource();
        await _coordinator.StartServerAsync(Profile, AddLog, _cts.Token);
        RaisePropertyChanged(nameof(IsServerRunning));
        RaisePropertyChanged(nameof(ServerStateText));
        StatusText = _coordinator.State.StatusText;
    }

    private async Task StopServerAsync()
    {
        _cts?.Cancel();
        _cts = new CancellationTokenSource();
        await _coordinator.StopServerAsync(Profile, ServerStopMode.RconQuit, AddLog, _cts.Token);
        RaisePropertyChanged(nameof(IsServerRunning));
        RaisePropertyChanged(nameof(ServerStateText));
        StatusText = _coordinator.State.StatusText;
    }

    private async Task SendRconAsync()
    {
        _cts?.Cancel();
        _cts = new CancellationTokenSource();
        var response = await _coordinator.SendRconAsync(Profile, RconCommand, _cts.Token);
        RconResponse = response.Succeeded ? response.ResponseText : response.Summary;
        AddLog(new LogEntry
        {
            Source = "RCON",
            LineType = response.Succeeded ? SteamCmdLineType.Info : SteamCmdLineType.Error,
            Message = response.Succeeded ? $"> {RconCommand}" : response.Summary
        });
    }

    private void UpdateProgress(int? percent, string? text)
    {
        if (percent.HasValue)
            ProgressPercent = percent.Value;
        if (!string.IsNullOrWhiteSpace(text))
            StatusText = text;
    }

    private void AddLog(LogEntry entry)
    {
        App.Current.Dispatcher.Invoke(() =>
        {
            Logs.Add(entry);
            while (Logs.Count > 500)
                Logs.RemoveAt(0);
        });
    }
}
