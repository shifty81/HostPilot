using System.Text;

namespace SteamCmdRconPack.Services;

internal static class RconPacket
{
    public const int Auth = 3;
    public const int ExecCommand = 2;
    public const int ResponseValue = 0;
    public const int AuthResponse = 2;

    public static byte[] Create(int id, int type, string body)
    {
        var bodyBytes = Encoding.ASCII.GetBytes(body);
        var size = 4 + 4 + bodyBytes.Length + 2;
        using var ms = new MemoryStream();
        using var writer = new BinaryWriter(ms, Encoding.ASCII, true);
        writer.Write(size);
        writer.Write(id);
        writer.Write(type);
        writer.Write(bodyBytes);
        writer.Write((short)0);
        return ms.ToArray();
    }
}
