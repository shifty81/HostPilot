using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SteamCmdRconPack.Models;

namespace SteamCmdRconPack.Services;

public sealed class RconClient
{
    public async Task<RconResponse> ExecuteAsync(string host, int port, string password, string command, CancellationToken cancellationToken)
    {
        try
        {
            using var client = new TcpClient();
            await client.ConnectAsync(host, port, cancellationToken);
            using var stream = client.GetStream();

            await SendPacketAsync(stream, 1, RconPacket.Auth, password, cancellationToken);
            var authPacket = await ReadPacketAsync(stream, cancellationToken);
            if (authPacket.Id == -1)
            {
                return new RconResponse { Succeeded = false, Summary = "RCON authentication failed.", ResponseText = string.Empty };
            }

            await SendPacketAsync(stream, 2, RconPacket.ExecCommand, command, cancellationToken);
            var response = await ReadPacketAsync(stream, cancellationToken);

            return new RconResponse
            {
                Succeeded = true,
                Summary = $"RCON command '{command}' executed.",
                ResponseText = response.Body
            };
        }
        catch (Exception ex)
        {
            return new RconResponse { Succeeded = false, Summary = ex.Message, ResponseText = string.Empty };
        }
    }

    private static async Task SendPacketAsync(NetworkStream stream, int id, int type, string body, CancellationToken cancellationToken)
    {
        var packet = RconPacket.Create(id, type, body);
        await stream.WriteAsync(packet, cancellationToken);
        await stream.FlushAsync(cancellationToken);
    }

    private static async Task<(int Size, int Id, int Type, string Body)> ReadPacketAsync(NetworkStream stream, CancellationToken cancellationToken)
    {
        var lengthBytes = await ReadExactAsync(stream, 4, cancellationToken);
        var size = BitConverter.ToInt32(lengthBytes, 0);
        var payload = await ReadExactAsync(stream, size, cancellationToken);

        var id = BitConverter.ToInt32(payload, 0);
        var type = BitConverter.ToInt32(payload, 4);
        var bodyLength = size - 10;
        var body = bodyLength > 0 ? Encoding.ASCII.GetString(payload, 8, bodyLength) : string.Empty;
        return (size, id, type, body.TrimEnd('\0'));
    }

    private static async Task<byte[]> ReadExactAsync(NetworkStream stream, int count, CancellationToken cancellationToken)
    {
        var buffer = new byte[count];
        var offset = 0;

        while (offset < count)
        {
            var read = await stream.ReadAsync(buffer.AsMemory(offset, count - offset), cancellationToken);
            if (read <= 0)
                throw new IOException("Connection closed while reading RCON packet.");
            offset += read;
        }

        return buffer;
    }
}
