using System.Text;
using SteamCmdRconPack.Models;

namespace SteamCmdRconPack.Services;

public sealed class SteamCmdArgumentBuilder
{
    public string Build(SteamCmdProfile profile, SteamCmdJobKind jobKind)
    {
        var builder = new StringBuilder();
        builder.Append("+force_install_dir \"").Append(profile.InstallDirectory).Append("\" ");
        builder.Append("+login \"").Append(profile.Username).Append("\"");

        if (!string.IsNullOrWhiteSpace(profile.Password))
            builder.Append(' ').Append('"').Append(profile.Password).Append('"');

        if (!string.IsNullOrWhiteSpace(profile.SteamGuardCode))
            builder.Append(" +set_steam_guard_code \"").Append(profile.SteamGuardCode).Append("\"");

        builder.Append(" +app_update ").Append(profile.AppId);

        if (!string.IsNullOrWhiteSpace(profile.Branch) && !profile.Branch.Equals("public", StringComparison.OrdinalIgnoreCase))
            builder.Append(" -beta ").Append(profile.Branch);

        if (profile.ValidateFiles || jobKind == SteamCmdJobKind.Validate)
            builder.Append(" validate");

        builder.Append(" +quit");
        return builder.ToString();
    }
}
