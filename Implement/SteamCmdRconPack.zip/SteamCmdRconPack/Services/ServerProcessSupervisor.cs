using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using SteamCmdRconPack.Models;

namespace SteamCmdRconPack.Services;

public sealed class ServerProcessSupervisor
{
    private readonly RconClient _rconClient = new();
    private Process? _currentProcess;

    public ServerRunState CurrentState { get; } = new();

    public async Task StartAsync(SteamCmdProfile profile, Action<LogEntry>? onLog, CancellationToken cancellationToken)
    {
        if (CurrentState.IsRunning)
        {
            onLog?.Invoke(new LogEntry { Source = "Server", LineType = SteamCmdLineType.Warning, Message = "Server is already running." });
            return;
        }

        if (string.IsNullOrWhiteSpace(profile.ServerExePath) || !File.Exists(profile.ServerExePath))
        {
            onLog?.Invoke(new LogEntry { Source = "Server", LineType = SteamCmdLineType.Error, Message = $"Server executable not found: {profile.ServerExePath}" });
            return;
        }

        var psi = new ProcessStartInfo
        {
            FileName = profile.ServerExePath,
            Arguments = profile.ServerArguments,
            WorkingDirectory = Path.GetDirectoryName(profile.ServerExePath) ?? AppContext.BaseDirectory,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        _currentProcess = new Process { StartInfo = psi, EnableRaisingEvents = true };
        _currentProcess.Exited += (_, _) =>
        {
            CurrentState.IsRunning = false;
            CurrentState.StoppedUtc = DateTime.UtcNow;
            CurrentState.StatusText = "Stopped";
        };

        _currentProcess.Start();
        CurrentState.IsRunning = true;
        CurrentState.ProcessId = _currentProcess.Id;
        CurrentState.StartedUtc = DateTime.UtcNow;
        CurrentState.StatusText = "Running";

        onLog?.Invoke(new LogEntry { Source = "Server", LineType = SteamCmdLineType.Success, Message = $"Started server PID {_currentProcess.Id}." });

        _ = PumpOutputAsync(_currentProcess.StandardOutput, "Server", onLog, cancellationToken);
        _ = PumpOutputAsync(_currentProcess.StandardError, "Server", onLog, cancellationToken);
        await Task.CompletedTask;
    }

    public async Task<RconResponse> ExecuteRconAsync(SteamCmdProfile profile, string command, CancellationToken cancellationToken)
        => await _rconClient.ExecuteAsync(profile.Host, profile.RconPort, profile.RconPassword, command, cancellationToken);

    public async Task StopAsync(SteamCmdProfile profile, ServerStopMode stopMode, Action<LogEntry>? onLog, CancellationToken cancellationToken)
    {
        if (_currentProcess == null || _currentProcess.HasExited)
        {
            onLog?.Invoke(new LogEntry { Source = "Server", LineType = SteamCmdLineType.Warning, Message = "Server is not running." });
            CurrentState.IsRunning = false;
            CurrentState.StatusText = "Stopped";
            return;
        }

        if (stopMode == ServerStopMode.RconQuit)
        {
            var rcon = await ExecuteRconAsync(profile, "quit", cancellationToken);
            onLog?.Invoke(new LogEntry
            {
                Source = "RCON",
                LineType = rcon.Succeeded ? SteamCmdLineType.Info : SteamCmdLineType.Warning,
                Message = rcon.Succeeded ? (string.IsNullOrWhiteSpace(rcon.ResponseText) ? rcon.Summary : rcon.ResponseText) : rcon.Summary
            });
        }
        else if (stopMode == ServerStopMode.CtrlC)
        {
            try
            {
                if (!_currentProcess.CloseMainWindow())
                    onLog?.Invoke(new LogEntry { Source = "Server", LineType = SteamCmdLineType.Warning, Message = "CloseMainWindow was not accepted by the server process." });
            }
            catch (Exception ex)
            {
                onLog?.Invoke(new LogEntry { Source = "Server", LineType = SteamCmdLineType.Warning, Message = ex.Message });
            }
        }

        var timeout = TimeSpan.FromSeconds(Math.Max(5, profile.StopTimeoutSeconds));
        var stopAt = DateTime.UtcNow + timeout;

        while (!_currentProcess.HasExited && DateTime.UtcNow < stopAt)
        {
            await Task.Delay(500, cancellationToken);
        }

        if (!_currentProcess.HasExited)
        {
            _currentProcess.Kill(entireProcessTree: true);
            onLog?.Invoke(new LogEntry { Source = "Server", LineType = SteamCmdLineType.Warning, Message = "Forced server process termination after timeout." });
        }

        CurrentState.IsRunning = false;
        CurrentState.StoppedUtc = DateTime.UtcNow;
        CurrentState.StatusText = "Stopped";
        onLog?.Invoke(new LogEntry { Source = "Server", LineType = SteamCmdLineType.Success, Message = "Server stopped." });
    }

    private static async Task PumpOutputAsync(StreamReader reader, string source, Action<LogEntry>? onLog, CancellationToken cancellationToken)
    {
        while (!reader.EndOfStream && !cancellationToken.IsCancellationRequested)
        {
            var line = await reader.ReadLineAsync(cancellationToken);
            if (line is null)
                break;

            onLog?.Invoke(new LogEntry
            {
                Source = source,
                LineType = SteamCmdLineType.Info,
                Message = line
            });
        }
    }
}
