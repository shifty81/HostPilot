using SteamCmdRconPack.Models;

namespace SteamCmdRconPack.Services;

public sealed class SteamServerCoordinator
{
    private readonly SteamCmdRunner _steamCmdRunner = new();
    private readonly ServerProcessSupervisor _serverSupervisor = new();

    public ServerRunState State => _serverSupervisor.CurrentState;

    public Task<SteamCmdRunResult> InstallAsync(SteamCmdProfile profile, Action<LogEntry>? onLog, Action<int?, string?>? onProgress, CancellationToken cancellationToken)
        => _steamCmdRunner.RunAsync(profile, SteamCmdJobKind.Install, onLog, onProgress, cancellationToken);

    public Task<SteamCmdRunResult> UpdateAsync(SteamCmdProfile profile, Action<LogEntry>? onLog, Action<int?, string?>? onProgress, CancellationToken cancellationToken)
        => _steamCmdRunner.RunAsync(profile, SteamCmdJobKind.Update, onLog, onProgress, cancellationToken);

    public Task<SteamCmdRunResult> ValidateAsync(SteamCmdProfile profile, Action<LogEntry>? onLog, Action<int?, string?>? onProgress, CancellationToken cancellationToken)
        => _steamCmdRunner.RunAsync(profile, SteamCmdJobKind.Validate, onLog, onProgress, cancellationToken);

    public Task StartServerAsync(SteamCmdProfile profile, Action<LogEntry>? onLog, CancellationToken cancellationToken)
        => _serverSupervisor.StartAsync(profile, onLog, cancellationToken);

    public Task StopServerAsync(SteamCmdProfile profile, ServerStopMode stopMode, Action<LogEntry>? onLog, CancellationToken cancellationToken)
        => _serverSupervisor.StopAsync(profile, stopMode, onLog, cancellationToken);

    public Task<RconResponse> SendRconAsync(SteamCmdProfile profile, string command, CancellationToken cancellationToken)
        => _serverSupervisor.ExecuteRconAsync(profile, command, cancellationToken);
}
