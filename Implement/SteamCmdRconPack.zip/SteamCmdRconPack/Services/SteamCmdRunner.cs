using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using SteamCmdRconPack.Models;

namespace SteamCmdRconPack.Services;

public sealed class SteamCmdRunner
{
    private readonly SteamCmdOutputParser _parser = new();
    private readonly SteamCmdArgumentBuilder _argumentBuilder = new();

    public async Task<SteamCmdRunResult> RunAsync(
        SteamCmdProfile profile,
        SteamCmdJobKind jobKind,
        Action<LogEntry>? onLog,
        Action<int?, string?>? onProgress,
        CancellationToken cancellationToken)
    {
        if (!File.Exists(profile.SteamCmdPath))
        {
            return new SteamCmdRunResult
            {
                Succeeded = false,
                ExitCode = -1,
                Summary = $"SteamCMD not found: {profile.SteamCmdPath}"
            };
        }

        var arguments = _argumentBuilder.Build(profile, jobKind);
        var psi = new ProcessStartInfo
        {
            FileName = profile.SteamCmdPath,
            Arguments = arguments,
            WorkingDirectory = Path.GetDirectoryName(profile.SteamCmdPath) ?? AppContext.BaseDirectory,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        using var process = new Process { StartInfo = psi, EnableRaisingEvents = true };
        process.Start();

        onLog?.Invoke(new LogEntry { Source = "SteamCMD", LineType = SteamCmdLineType.Info, Message = $"Launching: {psi.FileName} {psi.Arguments}" });

        var stdOutTask = PumpReaderAsync(process.StandardOutput, onLog, onProgress, cancellationToken);
        var stdErrTask = PumpReaderAsync(process.StandardError, onLog, onProgress, cancellationToken);

        await process.WaitForExitAsync(cancellationToken);
        await Task.WhenAll(stdOutTask, stdErrTask);

        var succeeded = process.ExitCode == 0;
        var summary = succeeded ? $"SteamCMD {jobKind} completed." : $"SteamCMD {jobKind} failed with exit code {process.ExitCode}.";

        onLog?.Invoke(new LogEntry { Source = "SteamCMD", LineType = succeeded ? SteamCmdLineType.Success : SteamCmdLineType.Error, Message = summary });

        return new SteamCmdRunResult
        {
            Succeeded = succeeded,
            ExitCode = process.ExitCode,
            Summary = summary
        };
    }

    private async Task PumpReaderAsync(StreamReader reader, Action<LogEntry>? onLog, Action<int?, string?>? onProgress, CancellationToken cancellationToken)
    {
        while (!reader.EndOfStream && !cancellationToken.IsCancellationRequested)
        {
            var line = await reader.ReadLineAsync(cancellationToken);
            if (line is null)
                break;

            var parsed = _parser.Parse(line);
            onLog?.Invoke(new LogEntry
            {
                Source = "SteamCMD",
                LineType = parsed.LineType,
                Message = parsed.RawLine
            });

            if (parsed.Percent.HasValue || !string.IsNullOrWhiteSpace(parsed.StatusText))
                onProgress?.Invoke(parsed.Percent, parsed.StatusText);
        }
    }
}
