using System.Text.RegularExpressions;
using SteamCmdRconPack.Models;

namespace SteamCmdRconPack.Services;

public sealed class SteamCmdOutputParser
{
    private static readonly Regex PercentRegex = new(@"(?<pct>\d{1,3})%", RegexOptions.Compiled);

    public SteamCmdParsedLine Parse(string? line)
    {
        line ??= string.Empty;
        var trimmed = line.Trim();
        var parsed = new SteamCmdParsedLine { RawLine = trimmed, StatusText = trimmed };

        if (string.IsNullOrWhiteSpace(trimmed))
        {
            parsed.LineType = SteamCmdLineType.Unknown;
            return parsed;
        }

        var lower = trimmed.ToLowerInvariant();

        if (lower.Contains("success!") || lower.Contains("fully installed"))
        {
            parsed.LineType = SteamCmdLineType.Success;
            parsed.EventKey = "install.success";
            parsed.IsTerminalSuccess = true;
            return parsed;
        }

        if (lower.Contains("error!") || lower.Contains("failed") || lower.Contains("no subscription") || lower.Contains("invalid password"))
        {
            parsed.LineType = SteamCmdLineType.Error;
            parsed.EventKey = "install.error";
            parsed.IsTerminalFailure = true;
            return parsed;
        }

        if (lower.Contains("downloading update") || lower.Contains("download complete") || lower.Contains("extracting package") || lower.Contains("verifying installation"))
        {
            parsed.LineType = SteamCmdLineType.Progress;
            parsed.EventKey = "install.progress";
            var percentMatch = PercentRegex.Match(trimmed);
            if (percentMatch.Success && int.TryParse(percentMatch.Groups["pct"].Value, out var pct))
                parsed.Percent = Math.Clamp(pct, 0, 100);
            return parsed;
        }

        if (lower.Contains("update state") || lower.Contains("workshop") || lower.Contains("set_steam_guard_code") || lower.Contains("login"))
        {
            parsed.LineType = SteamCmdLineType.Info;
            return parsed;
        }

        if (lower.Contains("warning"))
        {
            parsed.LineType = SteamCmdLineType.Warning;
            return parsed;
        }

        parsed.LineType = SteamCmdLineType.Info;
        return parsed;
    }
}
