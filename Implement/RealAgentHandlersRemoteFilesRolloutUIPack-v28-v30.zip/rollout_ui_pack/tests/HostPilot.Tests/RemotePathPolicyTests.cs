using HostPilot.Remote.Files;
using Xunit;

namespace HostPilot.Tests;

public sealed class RemotePathPolicyTests
{
    [Fact]
    public void NormalizeUnderRoot_BlocksTraversal()
    {
        var policy = new RemotePathPolicy();
        Assert.ThrowsAny<System.Exception>(() => policy.NormalizeUnderRoot(@"C:\Servers", @"..\Windows"));
    }
}
