# V28 — Real Agent Handlers

## Goals
- Convert abstract remote command contracts into executable handlers on each node.
- Keep command execution typed, auditable, cancelable, and policy-gated.
- Provide handler boundaries for provider/game-specific execution later.

## Handler categories
- server install/update handlers
- start/stop/restart handlers
- backup/restore handlers
- health probe handlers
- log tail / artifact listing handlers
- file transfer accept/apply handlers

## Core rules
- Every handler must emit structured progress.
- Every handler must accept cancellation.
- Every handler must produce an operation result envelope.
- Every handler must write audit entries.
