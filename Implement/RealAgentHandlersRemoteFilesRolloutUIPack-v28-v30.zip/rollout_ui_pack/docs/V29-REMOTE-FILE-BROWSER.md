# V29 — Remote File Browser

## Goals
- Browse remote node file systems through agent-approved roots.
- Support safe upload, download, delete, rename, mkdir, extract, and tail-log actions.
- Support live transfer progress over SignalR/web and desktop UI.

## Safety boundaries
- root-scoped browsing only
- path normalization and traversal blocking
- extension/size policy checks
- optional protected paths denylist
