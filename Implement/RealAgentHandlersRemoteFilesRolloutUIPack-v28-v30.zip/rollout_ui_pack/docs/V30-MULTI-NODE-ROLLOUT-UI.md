# V30 — Multi-Node Rollout UI

## Goals
- Plan and execute rollouts across many nodes.
- Stage updates with concurrency windows, canary waves, approvals, and rollback hooks.
- Surface fleet-wide progress in WPF and web dashboards.

## Rollout concepts
- rollout plan
- rollout wave
- node assignment
- precheck result
- execution state
- rollback checkpoint
