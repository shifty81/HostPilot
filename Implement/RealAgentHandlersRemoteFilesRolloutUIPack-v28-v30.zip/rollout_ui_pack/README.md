# v28-v30 Real Agent Handlers + Remote File Browser + Multi-Node Rollout UI Pack

This pack adds the next runtime layer for the standalone server admin platform:

- **v28** real remote agent handlers for command execution and lifecycle operations
- **v29** remote file browser and transfer orchestration UI/service scaffolding
- **v30** multi-node rollout UI, staged deployment planning, and live progress aggregation

The pack is compile-oriented scaffold material intended to drop into the repo and be wired into the earlier v19-v27 packs.
