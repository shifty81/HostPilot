using System;
using System.IO;

namespace HostPilot.Remote.Files;

public sealed class RemotePathPolicy
{
    public string NormalizeUnderRoot(string rootPath, string requestedPath)
    {
        var combined = Path.GetFullPath(Path.Combine(rootPath, requestedPath ?? string.Empty));
        var normalizedRoot = Path.GetFullPath(rootPath);

        if (!combined.StartsWith(normalizedRoot, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("Path traversal attempt blocked.");
        }

        return combined;
    }
}
