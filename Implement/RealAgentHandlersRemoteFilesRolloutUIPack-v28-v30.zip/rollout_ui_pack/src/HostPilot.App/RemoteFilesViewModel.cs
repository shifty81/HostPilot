using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using HostPilot.Remote.Files;

namespace HostPilot.App;

public sealed class RemoteFilesViewModel
{
    private readonly RemoteFileBrowserService _service;

    public RemoteFilesViewModel(RemoteFileBrowserService service)
    {
        _service = service;
    }

    public ObservableCollection<RemoteFileEntry> Entries { get; } = new();
    public string CurrentPath { get; private set; } = string.Empty;
    public string SelectedNodeId { get; set; } = string.Empty;
    public string SelectedRootAlias { get; set; } = "server-root";
    public string SelectedRootPath { get; set; } = @"C:\Servers";

    public async Task RefreshAsync(string requestedPath, CancellationToken cancellationToken = default)
    {
        var listing = await _service.ListAsync(SelectedNodeId, SelectedRootAlias, SelectedRootPath, requestedPath, cancellationToken);
        Entries.Clear();
        foreach (var entry in listing.Entries)
        {
            Entries.Add(entry);
        }

        CurrentPath = listing.CurrentPath;
    }
}
