# v27 Remote Update Pipeline

## Purpose

This layer manages updates for the remote agent and other node-side runtime packages in a controlled way.

## Package model

Each update package should include:

- package ID
- version
- channel
- target runtime / OS / architecture
- hash
- signed manifest
- minimum compatible controller version
- optional migration notes
- rollback package reference

## Rollout stages

1. discover package
2. validate manifest and hash
3. stage package on node
4. preflight checks
5. operator approval or automation rule gate
6. apply update
7. restart affected service if needed
8. health verification window
9. commit or rollback

## Rollout modes

- single node
- canary subset
- batch wave
- whole fleet

## Failure handling

- preserve previous package
- preserve config
- emit failure reason and last successful checkpoint
- allow rollback action from UI
- never silently auto-delete last known good build
