# v26 Artifact Streaming + Remote File Transfer

## Purpose

This layer provides a live service for moving files and artifacts between controller and remote nodes.

That includes:

- server package uploads
- config sync
- mod zip/folder uploads
- backup download/export
- log archive pull
- crash dump retrieval
- template import/export

## Transport strategy

### Preferred
- **SFTP**

### Acceptable
- **FTPS**

### Legacy compatibility only
- **FTP**

Plain FTP should be disabled by default because credentials and payloads are not adequately protected.

## Provider abstraction

Use a provider model so one remote node can advertise which transfer types it supports. Example capabilities:

- `sftp`
- `ftps`
- `ftp-legacy`
- `direct-agent-stream`

## Core actions

- list directory
- create directory
- upload file
- download file
- delete file
- move/rename
- checksum verify
- open artifact stream
- enumerate transfer history

## Live service behavior

Each transfer should publish:

- bytes transferred
- total bytes if known
- rate estimate
- percent complete
- current path
- warnings/errors
- completion state

## Recommended UI

Per remote node, include a **Files** tab with:

- remote path tree
- upload button
- drag/drop target
- download/export actions
- transfer queue panel
- checksum / overwrite prompts
- mod/config/deployment shortcuts
