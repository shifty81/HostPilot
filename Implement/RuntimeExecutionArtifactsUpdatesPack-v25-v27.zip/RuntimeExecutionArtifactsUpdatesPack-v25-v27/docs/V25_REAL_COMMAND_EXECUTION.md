# v25 Real Command Execution

## Purpose

This layer turns remote actions into **typed, policy-guarded commands** instead of ad hoc strings. It is the runtime bridge between:

- remote node selection
- browser/WPF operator actions
- automation events
- operation queue scheduling
- actual bounded execution on the node

## Command model

Commands should be registered descriptors with:

- command key
- display name
- argument schema reference
- risk level
- required permissions
- handler key
- timeout default
- supports cluster / single-node flags

## Good command examples

- `server.install`
- `server.start`
- `server.stop`
- `server.restart`
- `server.validate`
- `server.backup.create`
- `server.mods.sync`
- `server.config.push`
- `node.logs.collect`
- `node.agent.restart`

## Bad command examples

- arbitrary shell text from UI
- path-less delete operations
- commands without server/node scope
- handlers that bypass audit/policy

## Execution flow

1. UI or automation creates `RemoteExecutionRequest`.
2. Policy validates operator permissions, node scope, risk, and argument sanity.
3. Execution record is created with correlation ID.
4. Executor invokes whitelisted handler.
5. Progress events stream back to event bus / SignalR / WPF.
6. Final result persists with duration, outcome, and optional artifact links.

## Integration seams

- existing server manager / install manager
- RCON service
- backup service
- deployment manifests
- automation pack triggers/actions
- notification center
