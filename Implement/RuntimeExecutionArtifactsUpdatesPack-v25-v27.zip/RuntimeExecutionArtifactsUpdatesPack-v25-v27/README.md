# Real Command Execution + Artifact Streaming + Remote Update Pipeline Pack v25-v27

This pack extends the standalone server admin application with three runtime-oriented layers:

- **v25 Real Command Execution**: a guarded, correlated, whitelisted remote execution pipeline for installs, starts, stops, restarts, backups, validation, and maintenance operations.
- **v26 Artifact Streaming**: live log/file/artifact transfer plumbing for remote nodes, including a **managed file transfer service** for remote servers. The design strongly prefers **SFTP** and optionally **FTPS**. Plain FTP can be exposed only as a legacy compatibility mode and should remain disabled by default.
- **v27 Remote Update Pipeline**: staged agent/package update workflow with manifest validation, rollout policy, health gates, rollback seams, and audit hooks.

The pack is compile-oriented scaffold code. It is intentionally not pretending to be production complete, but it is shaped so it can be dropped into your repo and wired into the earlier packs:

- v16-v18 runtime automation
- v19-v21 remote nodes + web runtime control
- v22-v24 remote agent service + secure transport + browser UI

---

## What changed for your remote server file-transfer requirement

Instead of bolting on an unsafe raw FTP feature, this pack introduces a **Remote File Transfer Service** with:

- provider abstraction for **SFTP**, **FTPS**, and optional legacy **FTP**
- live upload/download progress events
- remote artifact browsing contracts
- deployment bundle push/pull hooks
- backup export/import transfer seams
- streamed log download and archive retrieval
- checksum validation and resumable-transfer seam points
- browser-facing file operations DTOs and pages

That gives you the “FTP live service” behavior you want while keeping the architecture compatible with safer transport choices.

---

## Suggested repo placement

```text
src/
  HostPilot.Core/
  HostPilot.Application/
  HostPilot.Remote.Contracts/
  HostPilot.Remote.Execution/
  HostPilot.Remote.Transfer/
  HostPilot.Remote.Updates/
  HostPilot.Web/
  HostPilot.Wpf/
```

Replace `HostPilot` with the final solution namespace if you rename later.

---

## Pack layout

```text
RuntimeExecutionArtifactsUpdatesPack-v25-v27/
  docs/
  src/
    HostPilot.Remote.Contracts/
    HostPilot.Remote.Execution/
    HostPilot.Remote.Transfer/
    HostPilot.Remote.Updates/
    HostPilot.Web/
    HostPilot.Wpf/
  tests/
```

---

## High-level goals

### v25 Real Command Execution

- command registry with explicit handler mapping
- policy-checked execution scopes
- correlation IDs and progress streaming
- bounded process execution adapters
- typed command arguments instead of arbitrary shell text
- command history + audit seams

### v26 Artifact Streaming + Remote File Transfer

- upload/download/list/delete/mkdir abstractions
- live progress reporting to WPF and browser UI
- deployment artifact channels
- backup/archive pull and push flows
- checksum validation and resumable transfer hooks
- SFTP-first strategy with FTPS support and legacy FTP off by default

### v27 Remote Update Pipeline

- signed package manifest model
- staged rollout workflow
- canary / batch / fleet policy surface
- preflight checks and health gates
- rollback manifest + previous-version preservation hooks
- update event stream, audit trail, and operator approval seams

---

## Integration order

1. Add/update shared remote contracts.
2. Add command execution project and wire existing operation queue/server lifecycle services.
3. Add transfer project and hook backups, archives, mod uploads, config push/pull, and log retrieval.
4. Add update project and point it at your package/build/artifact source.
5. Surface pages and WPF tabs for command history, file transfer, and node updates.
6. Replace mock executors and transfer providers with production implementations.
7. Add persistent storage for command history, transfer sessions, and update rollout state.

---

## Important implementation notes

- Do **not** expose a raw “type any shell command” textbox in browser UI.
- Keep remote execution manifest-backed and handler-whitelisted.
- Prefer **SFTP** for remote file movement; **FTPS** is acceptable where required.
- Keep plain FTP disabled by default and clearly marked legacy/insecure.
- Every transfer and update action should emit audit records.
- Large artifact moves should support chunking/resume later even if first version is basic.
- Remote updates should require package validation before apply.
