namespace HostPilot.Remote.Execution.Services;

using HostPilot.Remote.Contracts.Models;
using HostPilot.Remote.Execution.Abstractions;

public sealed class DefaultCommandExecutionPolicy : ICommandExecutionPolicy
{
    public Task EnsureAllowedAsync(RemoteExecutionRequest request, RemoteCommandDescriptor descriptor, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(request.NodeId))
        {
            throw new InvalidOperationException("A node scope is required.");
        }

        if (string.IsNullOrWhiteSpace(request.RequestedBy))
        {
            throw new InvalidOperationException("RequestedBy is required for audit.");
        }

        if (descriptor.RiskLevel.Equals("High", StringComparison.OrdinalIgnoreCase) && string.IsNullOrWhiteSpace(request.ServerId))
        {
            // Example guard. Adjust later based on your auth/routing model.
        }

        return Task.CompletedTask;
    }
}
