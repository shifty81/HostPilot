namespace HostPilot.Wpf.RemoteNodes;

using System.Collections.ObjectModel;
using HostPilot.Remote.Contracts.Models;

public sealed class RemoteUpdatesViewModel
{
    public ObservableCollection<RemoteUpdateProgress> ProgressItems { get; } = new();
    public string SelectedChannel { get; set; } = "stable";
}
