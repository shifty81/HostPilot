namespace HostPilot.Remote.Updates.Tests;

using HostPilot.Remote.Contracts.Models;
using HostPilot.Remote.Updates.Services;

public sealed class UpdateManifestValidatorTests
{
    [Fact]
    public void Rejects_Unsigned_Manifest()
    {
        var validator = new UpdateManifestValidator();
        var manifest = new RemoteUpdatePackageManifest { PackageId = "agent", Version = "1.0.0", Sha256 = "abc", IsSigned = false };
        Assert.False(validator.IsValid(manifest));
    }
}
