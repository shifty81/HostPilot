namespace HostPilot.Remote.Transfer.Tests;

using HostPilot.Remote.Transfer.Models;

public sealed class TransferValidationTests
{
    [Fact]
    public void Can_Construct_Result()
    {
        var result = new RemoteTransferValidationResult { IsValid = true, Message = "ok" };
        Assert.True(result.IsValid);
    }
}
