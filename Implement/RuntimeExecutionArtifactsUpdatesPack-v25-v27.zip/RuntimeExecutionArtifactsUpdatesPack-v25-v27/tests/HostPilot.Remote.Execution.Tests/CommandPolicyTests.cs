namespace HostPilot.Remote.Execution.Tests;

using HostPilot.Remote.Contracts.Models;
using HostPilot.Remote.Execution.Services;

public sealed class CommandPolicyTests
{
    [Fact]
    public async Task Throws_When_Node_Is_Missing()
    {
        var policy = new DefaultCommandExecutionPolicy();
        var descriptor = new RemoteCommandDescriptor { CommandKey = "server.start", DisplayName = "Start" };
        var request = new RemoteExecutionRequest { RequestedBy = "tester" };

        await Assert.ThrowsAsync<InvalidOperationException>(() => policy.EnsureAllowedAsync(request, descriptor));
    }
}
