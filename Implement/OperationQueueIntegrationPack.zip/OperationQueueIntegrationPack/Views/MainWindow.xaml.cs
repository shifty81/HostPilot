using System.Windows;
using OperationQueueIntegrationPack.ViewModels;

namespace OperationQueueIntegrationPack.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainWindowViewModel();
    }
}
