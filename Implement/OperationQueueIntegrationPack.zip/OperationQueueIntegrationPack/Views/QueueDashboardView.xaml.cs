using System.Windows.Controls;

namespace OperationQueueIntegrationPack.Views;

public partial class QueueDashboardView : UserControl
{
    public QueueDashboardView()
    {
        InitializeComponent();
    }
}
