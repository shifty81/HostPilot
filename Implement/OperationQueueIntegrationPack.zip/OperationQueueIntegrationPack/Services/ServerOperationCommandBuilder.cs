using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class ServerOperationCommandBuilder
{
    private readonly OperationFactory _factory = new();

    public OperationRequest BuildInstall(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.InstallServer, profileId, serverName, manifestId, values);

    public OperationRequest BuildUpdate(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.UpdateServer, profileId, serverName, manifestId, values);

    public OperationRequest BuildValidate(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.ValidateConfiguration, profileId, serverName, manifestId, values);

    public OperationRequest BuildStart(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.StartServer, profileId, serverName, manifestId, values);

    public OperationRequest BuildStop(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.StopServer, profileId, serverName, manifestId, values);

    public OperationRequest BuildRestart(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.RestartServer, profileId, serverName, manifestId, values);

    public OperationRequest BuildBackup(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.BackupServer, profileId, serverName, manifestId, values);

    public OperationRequest BuildInstallMods(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.InstallMods, profileId, serverName, manifestId, values);

    public OperationRequest BuildImportExisting(string profileId, string serverName, string manifestId, IReadOnlyDictionary<string, object?> values)
        => _factory.Create(OperationKind.ImportExistingServer, profileId, serverName, manifestId, values);
}
