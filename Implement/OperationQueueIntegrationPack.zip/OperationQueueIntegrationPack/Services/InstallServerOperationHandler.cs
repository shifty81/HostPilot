using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class InstallServerOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.InstallServer;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (10, "Validating install profile", 350);
        yield return (25, "Preparing install directories", 450);
        yield return (55, "Downloading server payload", 700);
        yield return (80, "Applying configuration", 500);
        yield return (100, "Install complete", 250);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Installed {request.Context.ServerDisplayName}");
}
