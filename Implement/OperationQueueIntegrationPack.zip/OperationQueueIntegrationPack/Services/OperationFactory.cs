using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class OperationFactory
{
    public OperationRequest Create(OperationKind kind, string profileId, string serverDisplayName, string manifestId, IReadOnlyDictionary<string, object?> values)
    {
        return new OperationRequest
        {
            Kind = kind,
            DisplayName = BuildDisplayName(kind, serverDisplayName),
            Context = new OperationContext
            {
                ProfileId = profileId,
                ServerDisplayName = serverDisplayName,
                ManifestId = manifestId,
                Values = values
            },
            RequiresExclusiveServerLock = kind is not OperationKind.ValidateConfiguration
        };
    }

    private static string BuildDisplayName(OperationKind kind, string serverDisplayName)
        => kind switch
        {
            OperationKind.InstallServer => $"Install {serverDisplayName}",
            OperationKind.UpdateServer => $"Update {serverDisplayName}",
            OperationKind.ValidateConfiguration => $"Validate {serverDisplayName}",
            OperationKind.StartServer => $"Start {serverDisplayName}",
            OperationKind.StopServer => $"Stop {serverDisplayName}",
            OperationKind.RestartServer => $"Restart {serverDisplayName}",
            OperationKind.BackupServer => $"Backup {serverDisplayName}",
            OperationKind.InstallMods => $"Install mods for {serverDisplayName}",
            OperationKind.ImportExistingServer => $"Import existing install for {serverDisplayName}",
            _ => $"Run {kind} for {serverDisplayName}"
        };
}
