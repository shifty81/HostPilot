using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class UpdateServerOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.UpdateServer;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (15, "Checking installed build", 350);
        yield return (50, "Downloading update files", 650);
        yield return (80, "Applying update", 450);
        yield return (100, "Server updated", 250);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Updated {request.Context.ServerDisplayName}");
}
