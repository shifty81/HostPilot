using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public interface IOperationHandler
{
    OperationKind Kind { get; }
    Task<OperationResult> ExecuteAsync(OperationRequest request, IProgress<OperationProgress> progress, CancellationToken cancellationToken);
}
