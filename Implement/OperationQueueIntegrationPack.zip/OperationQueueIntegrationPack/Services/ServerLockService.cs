namespace OperationQueueIntegrationPack.Services;

public sealed class ServerLockService
{
    private readonly HashSet<string> _lockedProfileIds = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _sync = new();

    public bool TryAcquire(string profileId)
    {
        lock (_sync)
        {
            return _lockedProfileIds.Add(profileId);
        }
    }

    public void Release(string profileId)
    {
        lock (_sync)
        {
            _lockedProfileIds.Remove(profileId);
        }
    }
}
