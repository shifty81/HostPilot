using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class StopServerOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.StopServer;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (25, "Sending shutdown signal", 250);
        yield return (70, "Waiting for clean exit", 550);
        yield return (100, "Server stopped", 150);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Stopped {request.Context.ServerDisplayName}");
}
