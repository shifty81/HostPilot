using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class RestartServerOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.RestartServer;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (20, "Stopping server", 350);
        yield return (45, "Waiting for stop confirmation", 350);
        yield return (75, "Starting server", 500);
        yield return (100, "Restart complete", 200);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Restarted {request.Context.ServerDisplayName}");
}
