using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class StartServerOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.StartServer;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (20, "Running pre-start validation", 250);
        yield return (50, "Launching process", 450);
        yield return (80, "Waiting for ready signal", 550);
        yield return (100, "Server online", 150);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Started {request.Context.ServerDisplayName}");
}
