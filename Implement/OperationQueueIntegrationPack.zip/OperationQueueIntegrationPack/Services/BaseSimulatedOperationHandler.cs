using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public abstract class BaseSimulatedOperationHandler : IOperationHandler
{
    public abstract OperationKind Kind { get; }

    public async Task<OperationResult> ExecuteAsync(OperationRequest request, IProgress<OperationProgress> progress, CancellationToken cancellationToken)
    {
        foreach (var step in GetSteps(request))
        {
            cancellationToken.ThrowIfCancellationRequested();
            progress.Report(new OperationProgress { Percent = step.percent, Message = step.message });
            await Task.Delay(step.delayMs, cancellationToken);
        }

        return BuildResult(request);
    }

    protected abstract IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request);
    protected abstract OperationResult BuildResult(OperationRequest request);
}
