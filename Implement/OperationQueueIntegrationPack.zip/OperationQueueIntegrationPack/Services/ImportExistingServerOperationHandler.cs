using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class ImportExistingServerOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.ImportExistingServer;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (20, "Scanning existing install", 400);
        yield return (55, "Reading known config files", 450);
        yield return (85, "Building deployment profile", 300);
        yield return (100, "Import complete", 150);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Imported existing server for {request.Context.ServerDisplayName}");
}
