using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class BackupServerOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.BackupServer;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (15, "Preparing backup target", 250);
        yield return (45, "Capturing world and configs", 650);
        yield return (75, "Compressing backup archive", 500);
        yield return (100, "Backup complete", 200);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Backup finished for {request.Context.ServerDisplayName}");
}
