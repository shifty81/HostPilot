using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using System.Windows;
using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class OperationQueueService
{
    private readonly ConcurrentQueue<(OperationRequest request, QueueOperationRecord record)> _queue = new();
    private readonly SemaphoreSlim _signal = new(0);
    private readonly OperationHandlerRegistry _handlerRegistry;
    private readonly ServerLockService _serverLockService;
    private readonly CancellationTokenSource _shutdown = new();

    public ObservableCollection<QueueOperationRecord> Operations { get; } = new();

    public OperationQueueService(OperationHandlerRegistry handlerRegistry, ServerLockService serverLockService)
    {
        _handlerRegistry = handlerRegistry;
        _serverLockService = serverLockService;
        _ = Task.Run(ProcessLoopAsync);
    }

    public QueueOperationRecord Enqueue(OperationRequest request)
    {
        var record = QueueOperationRecord.FromRequest(request);
        Application.Current.Dispatcher.Invoke(() => Operations.Add(record));
        _queue.Enqueue((request, record));
        record.Status = OperationStatus.Queued;
        record.CurrentMessage = "Queued";
        AppendLog(record, "Queued operation.");
        _signal.Release();
        return record;
    }

    public void Stop() => _shutdown.Cancel();

    private async Task ProcessLoopAsync()
    {
        while (!_shutdown.IsCancellationRequested)
        {
            try
            {
                await _signal.WaitAsync(_shutdown.Token);
            }
            catch (OperationCanceledException)
            {
                break;
            }

            if (!_queue.TryDequeue(out var item))
                continue;

            await ProcessItemAsync(item.request, item.record, _shutdown.Token);
        }
    }

    private async Task ProcessItemAsync(OperationRequest request, QueueOperationRecord record, CancellationToken cancellationToken)
    {
        var profileId = request.Context.ProfileId;
        var lockAcquired = !request.RequiresExclusiveServerLock || _serverLockService.TryAcquire(profileId);

        if (!lockAcquired)
        {
            _queue.Enqueue((request, record));
            AppendLog(record, "Server busy. Re-queued operation.");
            await Task.Delay(350, cancellationToken);
            _signal.Release();
            return;
        }

        try
        {
            record.Status = OperationStatus.Running;
            record.StartedUtc = DateTime.UtcNow;
            record.CurrentMessage = "Running";
            AppendLog(record, "Started operation.");

            var handler = _handlerRegistry.GetHandler(request.Kind);
            var progress = new Progress<OperationProgress>(p =>
            {
                record.Percent = p.Percent;
                record.CurrentMessage = p.Message;
                AppendLog(record, p.Message);
            });

            var result = await handler.ExecuteAsync(request, progress, cancellationToken);
            record.FinishedUtc = DateTime.UtcNow;
            record.ResultSummary = result.Summary;
            record.Percent = 100;
            record.Status = result.Success ? OperationStatus.Succeeded : OperationStatus.Failed;
            record.CurrentMessage = result.Summary;
            AppendLog(record, result.Summary);
        }
        catch (OperationCanceledException)
        {
            record.FinishedUtc = DateTime.UtcNow;
            record.Status = OperationStatus.Cancelled;
            record.CurrentMessage = "Cancelled";
            record.ResultSummary = "Cancelled";
            AppendLog(record, "Operation cancelled.");
        }
        catch (Exception ex)
        {
            record.FinishedUtc = DateTime.UtcNow;
            record.Status = OperationStatus.Failed;
            record.CurrentMessage = ex.Message;
            record.ResultSummary = "Failed";
            AppendLog(record, ex.ToString());
        }
        finally
        {
            if (request.RequiresExclusiveServerLock)
                _serverLockService.Release(profileId);
        }
    }

    private static void AppendLog(QueueOperationRecord record, string message)
    {
        Application.Current.Dispatcher.Invoke(() => record.Logs.Add(new OperationLogEntry
        {
            TimestampUtc = DateTime.UtcNow,
            Message = message
        }));
    }
}
