using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class InstallModsOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.InstallMods;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (15, "Resolving mod dependency graph", 450);
        yield return (50, "Downloading mod packages", 650);
        yield return (85, "Installing mods", 450);
        yield return (100, "Mods installed", 150);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Installed mods for {request.Context.ServerDisplayName}");
}
