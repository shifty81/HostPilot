using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class OperationHandlerRegistry
{
    private readonly Dictionary<OperationKind, IOperationHandler> _handlers;

    public OperationHandlerRegistry(IEnumerable<IOperationHandler> handlers)
    {
        _handlers = handlers.ToDictionary(x => x.Kind, x => x);
    }

    public IOperationHandler GetHandler(OperationKind kind)
    {
        if (_handlers.TryGetValue(kind, out var handler))
            return handler;

        throw new InvalidOperationException($"No operation handler registered for {kind}.");
    }
}
