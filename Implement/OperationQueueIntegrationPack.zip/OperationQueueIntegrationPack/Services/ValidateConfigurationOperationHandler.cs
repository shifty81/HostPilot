using OperationQueueIntegrationPack.Models;

namespace OperationQueueIntegrationPack.Services;

public sealed class ValidateConfigurationOperationHandler : BaseSimulatedOperationHandler
{
    public override OperationKind Kind => OperationKind.ValidateConfiguration;

    protected override IEnumerable<(int percent, string message, int delayMs)> GetSteps(OperationRequest request)
    {
        yield return (20, "Reading manifest values", 250);
        yield return (55, "Checking required paths and ports", 350);
        yield return (85, "Verifying runtime arguments", 300);
        yield return (100, "Configuration validated", 200);
    }

    protected override OperationResult BuildResult(OperationRequest request)
        => OperationResult.Succeeded($"Validated configuration for {request.Context.ServerDisplayName}");
}
