using System.Windows;

namespace OperationQueueIntegrationPack;

public partial class App : Application
{
}
