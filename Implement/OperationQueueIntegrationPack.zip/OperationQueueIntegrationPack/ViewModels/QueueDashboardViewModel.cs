using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using OperationQueueIntegrationPack.Commands;
using OperationQueueIntegrationPack.Models;
using OperationQueueIntegrationPack.Services;

namespace OperationQueueIntegrationPack.ViewModels;

public sealed class QueueDashboardViewModel : ViewModelBase
{
    private readonly ServerOperationCommandBuilder _commandBuilder = new();
    private QueueOperationRecord? _selectedOperation;

    public SampleDeploymentProfileViewModel Deployment { get; } = new();
    public OperationQueueService QueueService { get; }
    public ObservableCollection<QueueOperationRecord> Operations => QueueService.Operations;

    public QueueOperationRecord? SelectedOperation
    {
        get => _selectedOperation;
        set => SetProperty(ref _selectedOperation, value);
    }

    public ICommand EnqueueInstallCommand { get; }
    public ICommand EnqueueValidateCommand { get; }
    public ICommand EnqueueStartCommand { get; }
    public ICommand EnqueueStopCommand { get; }
    public ICommand EnqueueRestartCommand { get; }
    public ICommand EnqueueBackupCommand { get; }
    public ICommand EnqueueModsCommand { get; }
    public ICommand EnqueueUpdateCommand { get; }
    public ICommand EnqueueImportCommand { get; }

    public QueueDashboardViewModel()
    {
        var registry = new OperationHandlerRegistry(new IOperationHandler[]
        {
            new InstallServerOperationHandler(),
            new UpdateServerOperationHandler(),
            new ValidateConfigurationOperationHandler(),
            new StartServerOperationHandler(),
            new StopServerOperationHandler(),
            new RestartServerOperationHandler(),
            new BackupServerOperationHandler(),
            new InstallModsOperationHandler(),
            new ImportExistingServerOperationHandler()
        });

        QueueService = new OperationQueueService(registry, new ServerLockService());

        EnqueueInstallCommand = new RelayCommand(_ => EnqueueInstall());
        EnqueueValidateCommand = new RelayCommand(_ => EnqueueValidate());
        EnqueueStartCommand = new RelayCommand(_ => EnqueueStart());
        EnqueueStopCommand = new RelayCommand(_ => EnqueueStop());
        EnqueueRestartCommand = new RelayCommand(_ => EnqueueRestart());
        EnqueueBackupCommand = new RelayCommand(_ => EnqueueBackup());
        EnqueueModsCommand = new RelayCommand(_ => EnqueueMods());
        EnqueueUpdateCommand = new RelayCommand(_ => EnqueueUpdate());
        EnqueueImportCommand = new RelayCommand(_ => EnqueueImport());
    }

    private void EnqueueInstall() => Select(QueueService.Enqueue(_commandBuilder.BuildInstall(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));
    private void EnqueueValidate() => Select(QueueService.Enqueue(_commandBuilder.BuildValidate(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));
    private void EnqueueStart() => Select(QueueService.Enqueue(_commandBuilder.BuildStart(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));
    private void EnqueueStop() => Select(QueueService.Enqueue(_commandBuilder.BuildStop(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));
    private void EnqueueRestart() => Select(QueueService.Enqueue(_commandBuilder.BuildRestart(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));
    private void EnqueueBackup() => Select(QueueService.Enqueue(_commandBuilder.BuildBackup(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));
    private void EnqueueMods() => Select(QueueService.Enqueue(_commandBuilder.BuildInstallMods(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));
    private void EnqueueUpdate() => Select(QueueService.Enqueue(_commandBuilder.BuildUpdate(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));
    private void EnqueueImport() => Select(QueueService.Enqueue(_commandBuilder.BuildImportExisting(Deployment.ProfileId, Deployment.ServerName, Deployment.ManifestId, Deployment.ToValues())));

    private void Select(QueueOperationRecord record)
    {
        SelectedOperation = record;
        RaisePropertyChanged(nameof(TotalQueued));
        RaisePropertyChanged(nameof(RunningCount));
    }

    public int TotalQueued => Operations.Count;
    public int RunningCount => Operations.Count(x => x.Status == OperationStatus.Running);
}
