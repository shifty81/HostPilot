namespace OperationQueueIntegrationPack.ViewModels;

public sealed class MainWindowViewModel : ViewModelBase
{
    public QueueDashboardViewModel Dashboard { get; } = new();
}
