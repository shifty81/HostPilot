namespace OperationQueueIntegrationPack.ViewModels;

public sealed class SampleDeploymentProfileViewModel : ViewModelBase
{
    private string _profileId = "alpha-profile";
    private string _serverName = "Alpha Survival";
    private string _manifestId = "steam-generic";
    private int _gamePort = 27015;
    private string _installPath = @"C:\Servers\AlphaSurvival";

    public string ProfileId
    {
        get => _profileId;
        set => SetProperty(ref _profileId, value);
    }

    public string ServerName
    {
        get => _serverName;
        set => SetProperty(ref _serverName, value);
    }

    public string ManifestId
    {
        get => _manifestId;
        set => SetProperty(ref _manifestId, value);
    }

    public int GamePort
    {
        get => _gamePort;
        set => SetProperty(ref _gamePort, value);
    }

    public string InstallPath
    {
        get => _installPath;
        set => SetProperty(ref _installPath, value);
    }

    public IReadOnlyDictionary<string, object?> ToValues() => new Dictionary<string, object?>
    {
        ["serverName"] = ServerName,
        ["gamePort"] = GamePort,
        ["installPath"] = InstallPath
    };
}
