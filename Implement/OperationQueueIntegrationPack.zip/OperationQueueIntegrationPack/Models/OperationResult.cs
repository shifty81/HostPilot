namespace OperationQueueIntegrationPack.Models;

public sealed class OperationResult
{
    public bool Success { get; init; }
    public string Summary { get; init; } = "";
    public string Details { get; init; } = "";

    public static OperationResult Succeeded(string summary, string details = "") => new()
    {
        Success = true,
        Summary = summary,
        Details = details
    };

    public static OperationResult Failed(string summary, string details = "") => new()
    {
        Success = false,
        Summary = summary,
        Details = details
    };
}
