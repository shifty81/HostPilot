namespace OperationQueueIntegrationPack.Models;

public sealed class OperationLogEntry
{
    public DateTime TimestampUtc { get; init; } = DateTime.UtcNow;
    public string Message { get; init; } = "";
}
