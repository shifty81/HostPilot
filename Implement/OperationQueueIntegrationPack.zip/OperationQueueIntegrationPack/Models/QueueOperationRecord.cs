using System.Collections.ObjectModel;
using OperationQueueIntegrationPack.ViewModels;

namespace OperationQueueIntegrationPack.Models;

public sealed class QueueOperationRecord : ViewModelBase
{
    private OperationStatus _status = OperationStatus.Pending;
    private int _percent;
    private string _currentMessage = "Waiting";
    private DateTime? _startedUtc;
    private DateTime? _finishedUtc;
    private string _resultSummary = "";

    public Guid Id { get; init; }
    public OperationKind Kind { get; init; }
    public string DisplayName { get; init; } = "";
    public string ServerDisplayName { get; init; } = "";
    public string ProfileId { get; init; } = "";
    public bool RequiresExclusiveServerLock { get; init; }
    public ObservableCollection<OperationLogEntry> Logs { get; } = new();

    public OperationStatus Status
    {
        get => _status;
        set => SetProperty(ref _status, value);
    }

    public int Percent
    {
        get => _percent;
        set => SetProperty(ref _percent, value);
    }

    public string CurrentMessage
    {
        get => _currentMessage;
        set => SetProperty(ref _currentMessage, value);
    }

    public DateTime? StartedUtc
    {
        get => _startedUtc;
        set => SetProperty(ref _startedUtc, value);
    }

    public DateTime? FinishedUtc
    {
        get => _finishedUtc;
        set => SetProperty(ref _finishedUtc, value);
    }

    public string ResultSummary
    {
        get => _resultSummary;
        set => SetProperty(ref _resultSummary, value);
    }

    public static QueueOperationRecord FromRequest(OperationRequest request) => new()
    {
        Id = request.Id,
        Kind = request.Kind,
        DisplayName = request.DisplayName,
        ServerDisplayName = request.Context.ServerDisplayName,
        ProfileId = request.Context.ProfileId,
        RequiresExclusiveServerLock = request.RequiresExclusiveServerLock,
        Status = OperationStatus.Pending,
        Percent = 0,
        CurrentMessage = "Pending"
    };
}
