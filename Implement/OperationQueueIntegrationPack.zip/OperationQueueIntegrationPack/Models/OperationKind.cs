namespace OperationQueueIntegrationPack.Models;

public enum OperationKind
{
    InstallServer,
    UpdateServer,
    ValidateConfiguration,
    StartServer,
    StopServer,
    RestartServer,
    BackupServer,
    InstallMods,
    ImportExistingServer
}
