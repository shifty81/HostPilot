namespace OperationQueueIntegrationPack.Models;

public sealed class OperationProgress
{
    public int Percent { get; set; }
    public string Message { get; set; } = "";
}
