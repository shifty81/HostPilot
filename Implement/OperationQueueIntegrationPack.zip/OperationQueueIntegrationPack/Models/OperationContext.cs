namespace OperationQueueIntegrationPack.Models;

public sealed class OperationContext
{
    public string ProfileId { get; init; } = "";
    public string ServerDisplayName { get; init; } = "";
    public string ManifestId { get; init; } = "";
    public IReadOnlyDictionary<string, object?> Values { get; init; } = new Dictionary<string, object?>();
}
