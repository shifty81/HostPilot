namespace OperationQueueIntegrationPack.Models;

public enum OperationStatus
{
    Pending,
    Queued,
    Running,
    Succeeded,
    Failed,
    Cancelled
}
