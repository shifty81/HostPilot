namespace OperationQueueIntegrationPack.Models;

public sealed class OperationRequest
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public OperationKind Kind { get; init; }
    public string DisplayName { get; init; } = "";
    public OperationContext Context { get; init; } = new();
    public bool RequiresExclusiveServerLock { get; init; } = true;
    public DateTime CreatedUtc { get; init; } = DateTime.UtcNow;
}
