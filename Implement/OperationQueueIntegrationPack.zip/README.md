# Operation Queue Integration Pack

This pack is a repo-ready WPF MVVM scaffold for turning deployment-form output into queued server operations.

## Included

- operation request and result models
- queue record model with live progress and logs
- operation handler registry
- server lock service for exclusive per-server operations
- background queue processor
- simulated handlers for:
  - InstallServer
  - UpdateServer
  - ValidateConfiguration
  - StartServer
  - StopServer
  - RestartServer
  - BackupServer
  - InstallMods
  - ImportExistingServer
- sample deployment profile VM
- dashboard UI for enqueueing operations and observing progress

## Important notes

This pack is designed as an integration scaffold. The handlers are simulated so the UI and queue architecture can be wired first. Replace each handler body with your real implementation logic.

## Recommended real-world replacement points

- InstallServerOperationHandler -> SteamCMD/provider/install workflow
- UpdateServerOperationHandler -> provider update workflow
- ValidateConfigurationOperationHandler -> manifest + config + file/path validation
- Start/Stop/Restart handlers -> process supervision layer
- BackupServerOperationHandler -> backup/archive service
- InstallModsOperationHandler -> workshop/curseforge/local import pipeline
- ImportExistingServerOperationHandler -> first-run detector/import system

## How to connect it to the dynamic deployment form layer

1. Build the deployment profile from manifest values.
2. Convert the profile into OperationContext.
3. Use ServerOperationCommandBuilder to create requests.
4. Enqueue them through OperationQueueService.
5. Bind Operations to queue dashboard/server card UI.

## Suggested next expansion

- add prioritization
- add dependency chaining
- add retry policy
- add cancellation tokens per record
- persist queue history to disk
- route notifications into the app notification center
- add per-cluster operation fanout and aggregation
