using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace HostPilot.Web.Execution.Hubs;

public sealed class ClusterTelemetryHub : Hub
{
    public Task SubscribeCluster(string clusterId)
    {
        return Groups.AddToGroupAsync(Context.ConnectionId, $"cluster:{clusterId}");
    }

    public Task SubscribeNode(string nodeId)
    {
        return Groups.AddToGroupAsync(Context.ConnectionId, $"node:{nodeId}");
    }
}
