using System.Threading;
using System.Threading.Tasks;
using HostPilot.Telemetry.Contracts;
using HostPilot.Web.Execution.Hubs;
using Microsoft.AspNetCore.SignalR;

namespace HostPilot.Web.Execution.Services;

public sealed class SignalRTelemetryBroadcaster : ITelemetryBroadcaster
{
    private readonly IHubContext<ClusterTelemetryHub> _hubContext;

    public SignalRTelemetryBroadcaster(IHubContext<ClusterTelemetryHub> hubContext)
    {
        _hubContext = hubContext;
    }

    public Task BroadcastAsync(string topic, object payload, CancellationToken cancellationToken)
    {
        return _hubContext.Clients.All.SendAsync(topic, payload, cancellationToken);
    }
}
