using System.Threading;
using System.Threading.Tasks;
using HostPilot.Core.Execution.Contracts;
using HostPilot.Core.Execution.Services;
using Microsoft.AspNetCore.Mvc;

namespace HostPilot.Web.Execution.Controllers;

[ApiController]
[Route("api/execution")]
public sealed class ClusterExecutionController : ControllerBase
{
    private readonly DistributedExecutionScheduler _scheduler;

    public ClusterExecutionController(DistributedExecutionScheduler scheduler)
    {
        _scheduler = scheduler;
    }

    [HttpPost("plans/run")]
    public async Task<IActionResult> RunPlan([FromBody] ExecutionPlan plan, CancellationToken cancellationToken)
    {
        await _scheduler.ScheduleAsync(plan, cancellationToken);
        return Accepted(new { plan.PlanId, Status = "Scheduled" });
    }
}
