# HostPilot v13–v15 Execution Pack

This pack extends the standalone HostPilot server admin application with:

- **v13** Distributed job scheduler and cluster orchestration core
- **v14** Node authentication, signed requests, encrypted payload envelope scaffolds
- **v15** Live telemetry, health aggregation, metrics streaming, and dashboard integration seams

This is a **compile-oriented scaffold pack** intended to be merged into the existing HostPilot solution.

## What is in this pack

- `docs/` detailed implementation notes and merge order
- `src/HostPilot.Core.Execution/` scheduling, leasing, orchestration, plans, retries
- `src/HostPilot.Security/` node trust, HMAC signing, token issuance, envelope contracts
- `src/HostPilot.Telemetry/` metrics, health snapshots, aggregation, stream hub contracts
- `src/HostPilot.Web.Execution/` ASP.NET Core endpoints and SignalR hub seams
- `src/HostPilot.Wpf.Execution/` MVVM viewmodels and dashboard adapters
- `tests/` starter test scaffolds

## Intent

This pack moves HostPilot from "multi-machine aware" into "active orchestrator".

The mental model becomes:

- **Nodes** = machines capable of executing workloads
- **Leases** = temporary scheduling rights for a job
- **Plans** = execution graphs with retries, dependencies, and placement rules
- **Trust** = signed and timestamped agent-server communication
- **Telemetry** = live truth of node capacity, workload health, and cluster state

## Merge order

1. Merge `HostPilot.Core.Execution`
2. Merge `HostPilot.Security`
3. Merge `HostPilot.Telemetry`
4. Merge `HostPilot.Web.Execution`
5. Merge `HostPilot.Wpf.Execution`
6. Wire tests and replace stub services with your existing concrete services

## Notes

- This pack preserves the current project direction as a **standalone server admin app**
- Atlas / NovaForge are not part of this pack
- Security uses a practical scaffold: bootstrap token -> trust record -> HMAC signed requests -> rotating session token seam
