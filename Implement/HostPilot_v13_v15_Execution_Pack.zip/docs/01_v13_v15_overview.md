# v13–v15 Overview

## v13: Distributed Execution and Cluster Scheduler

Goal: schedule operations across local or remote nodes with placement rules, leases, retries, and orchestration graphs.

Adds:
- execution plans
- node selection policies
- lease ownership
- dependency-aware task graphs
- failover candidate reselection
- placement constraints (provider, region, tags, capabilities)

## v14: Auth and Encryption Layer

Goal: prevent rogue agents and ensure trusted command flow.

Adds:
- node bootstrap token flow
- node trust records
- signed request middleware
- nonce + timestamp replay protection
- encrypted envelope contract seam
- session token rotation seam

## v15: Telemetry + Live Dashboard

Goal: give HostPilot a real-time operational brain.

Adds:
- node metrics ingestion
- job lifecycle stream
- health aggregation
- anomaly flags
- capacity snapshots
- dashboard viewmodels
- SignalR live update seam

## End-state capability

By the end of these three passes, HostPilot is no longer just dispatching commands. It becomes an orchestration runtime that can:

- choose where work should execute
- prove the caller is trusted
- understand cluster capacity in real time
- redirect work when nodes degrade
- surface live operational truth to the desktop UI and web control layer
