# Theory of Capabilities

## Where the project stands

HostPilot now has the architecture to become a real-time server orchestration platform.

Before v13–v15, the system could:
- manage deployments
- model providers
- support remote nodes
- understand mod ecosystems
- support future sharing and marketplace concepts

After v13–v15, the system can conceptually become:

- **placement aware**
- **trust aware**
- **state aware**
- **capacity aware**

That is a major transition.

## Capability ladder

### Layer 1 — Command execution
Run a local or remote operation.

### Layer 2 — Managed orchestration
Schedule execution with dependencies, leases, retries, and failover.

### Layer 3 — Trusted network
Ensure all participating nodes prove identity and integrity.

### Layer 4 — Live cluster intelligence
Observe workload health, node pressure, and execution drift in real time.

### Layer 5 — Policy-driven automation
Future step: automatic placement, balancing, repair, migration, and alert-driven actions.

## Resulting product identity

The strongest framing is:

> HostPilot is evolving into a game server orchestration platform with infrastructure-style manifests, trusted node execution, and live operational telemetry.

## Strategic differentiators

1. Manifest-driven deployment
2. Game/provider-specific operations
3. Mod-aware server lifecycle
4. Desktop + web dual control surface
5. Remote multi-node scheduling
6. Shareable templates and community ecosystem

## What this enables later

- automatic cluster rebalance
- "drain node" maintenance mode
- one-click migration of a server from one node to another
- scheduled backup policy tied to workload health
- mod update blast-radius checks
- region-aware server placement
- cluster-level rolling restarts
