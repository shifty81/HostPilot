# Merge Plan

## Phase 1 — Core execution

Merge:
- `src/HostPilot.Core.Execution`

Wire:
- existing operation queue into `ExecutionPlanCompiler`
- existing provider install/start/stop actions into `IRemoteWorkloadExecutor`
- existing node inventory into `INodeCatalog`

Replace stubs:
- `InMemoryLeaseStore`
- `RoundRobinNodeSelector`

## Phase 2 — Trust layer

Merge:
- `src/HostPilot.Security`

Wire:
- remote agent registration endpoint to `NodeBootstrapService`
- API middleware to `SignedRequestValidationMiddleware`

Replace stubs:
- key storage provider
- secret rotation provider
- persistent nonce cache

## Phase 3 — Telemetry

Merge:
- `src/HostPilot.Telemetry`

Wire:
- node heartbeat payloads to `TelemetryIngestService`
- operation status changes to `ExecutionEventBroadcaster`

Replace stubs:
- metrics persistence
- retention pruning
- alert delivery sink

## Phase 4 — UI + Web

Merge:
- `src/HostPilot.Web.Execution`
- `src/HostPilot.Wpf.Execution`

Wire:
- SignalR hub to dashboard
- cluster overview cards to `ClusterOperationsDashboardViewModel`
- node detail dialog to `NodeDetailViewModel`

## Recommended implementation order

1. Trust bootstrap
2. Scheduler placement
3. Lease store
4. Job dispatch
5. Telemetry ingest
6. Live dashboard
7. failover + automatic reschedule
