# Next Recommended Pack After v13–v15

The best next pack is:

## v16–v18 Runtime Automation Pack

- policy engine
- automatic failover runner
- maintenance/drain mode
- rolling restart coordinator
- backup and restore orchestration
- autoscaling hooks
- alert actions and remediation recipes

That pack would take HostPilot from "operator-controlled orchestration" into "policy-assisted orchestration."
