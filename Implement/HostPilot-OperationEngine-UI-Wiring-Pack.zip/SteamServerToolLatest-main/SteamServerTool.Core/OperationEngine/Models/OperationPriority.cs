namespace SteamServerTool.Core.OperationEngine.Models;

public enum OperationPriority
{
    Low = 0,
    Normal = 1,
    High = 2,
    Critical = 3
}
