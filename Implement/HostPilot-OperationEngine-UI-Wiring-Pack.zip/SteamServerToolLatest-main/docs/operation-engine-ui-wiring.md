# Operation Engine UI Wiring Pack

This pass wires the WPF shell to the new operation engine so install/start/stop actions are queued instead of executing directly from button handlers.

## Included changes
- Initializes the operation engine after config load.
- Subscribes the UI to queued/status/state events.
- Routes Steam-based install/update actions through `OperationType.InstallServer`.
- Routes start/stop actions through `OperationType.StartServer` and `OperationType.StopServer`.
- Disposes event subscriptions and the engine cleanly on window close.
- Exposes the engine event bus for UI subscription.

## Why this matters
This is the bridge that cuts off the double-click deploy bug at the UI boundary. The WPF layer no longer directly launches SteamCMD or server processes for the guarded paths; it asks the engine to do it.

## Remaining gaps after this pass
- Disable action buttons while matching operations are queued/running.
- Add a dedicated operations pane with queue/history/status badges.
- Surface per-server runtime snapshots directly in dashboard cards.
- Move Minecraft/Vintage Story downloads into operation handlers too, so everything shares one execution path.
- Add restart/update/backup handlers and cluster stop/sync handlers.
