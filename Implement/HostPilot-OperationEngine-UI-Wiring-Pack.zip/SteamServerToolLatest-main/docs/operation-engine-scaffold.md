# Operation Engine Scaffold

This scaffold adds a production-oriented orchestration foundation to the existing server admin codebase.

## Included

- In-memory event bus for UI subscriptions
- In-memory operation state store
- Priority-aware scheduler with per-target locking
- Operation engine worker pump with retries and timeout support
- Server state snapshot model for a single source of truth
- Guards to stop duplicate install/start/stop actions
- Handlers for install, start, stop, and cluster start queueing
- Bootstrap helper to wire the engine into the current `ServerManager` and `SteamCmdService`

## Primary folders

- `SteamServerTool.Core/OperationEngine/Models`
- `SteamServerTool.Core/OperationEngine/Events`
- `SteamServerTool.Core/OperationEngine/Abstractions`
- `SteamServerTool.Core/OperationEngine/Services`
- `SteamServerTool.Core/OperationEngine/Adapters`

## Current intent

This is a scaffold, not a full UI integration pass. It gives you the backbone needed to replace direct button-to-service execution with queued, stateful operations.

## Suggested next integration pass

1. Create a singleton `OperationEngineService` during app startup.
2. Route install/start/stop button actions to `QueueAsync(...)`.
3. Subscribe WPF view models to `OperationStatusChangedEvent` and `ServerStateChangedEvent`.
4. Replace ad hoc status polling with state snapshots from the store.
5. Add notification-center binding to operation failures and warnings.
6. Extend with backup/update/mod handlers and cluster config sync handlers.

## Important note

The `ClusterStartOperationHandler` is designed to queue ordered node starts. If you want cluster stop, cluster config sync, or drift detection next, those should be added as first-class handlers in the same pattern.
