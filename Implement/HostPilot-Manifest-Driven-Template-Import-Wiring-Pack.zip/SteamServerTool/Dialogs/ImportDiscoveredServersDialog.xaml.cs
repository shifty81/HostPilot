using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using SteamServerTool.Core.Models;

namespace SteamServerTool.Dialogs;

public partial class ImportDiscoveredServersDialog : Window
{
    private readonly ObservableCollection<ImportCandidateItem> _items;

    public IReadOnlyList<DiscoveredServerCandidate> SelectedCandidates =>
        _items.Where(i => i.IsSelected).Select(i => i.Candidate).ToList();

    public ImportDiscoveredServersDialog(IEnumerable<DiscoveredServerCandidate> candidates)
    {
        InitializeComponent();
        _items = new ObservableCollection<ImportCandidateItem>(candidates.Select(c => new ImportCandidateItem(c)));
        CandidatesGrid.ItemsSource = _items;
    }

    private void BtnSelectAll_Click(object sender, RoutedEventArgs e)
    {
        foreach (var item in _items)
            item.IsSelected = true;
    }

    private void BtnSkip_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }

    private void BtnImport_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = _items.Any(i => i.IsSelected);
        Close();
    }
}

public class ImportCandidateItem : INotifyPropertyChanged
{
    private bool _isSelected = true;

    public DiscoveredServerCandidate Candidate { get; }
    public string ConfidenceDisplay => $"{Candidate.Confidence:P0}";
    public string EvidenceSummary => string.Join(" | ", Candidate.Evidence.Take(3));

    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (_isSelected == value) return;
            _isSelected = value;
            OnPropertyChanged();
        }
    }

    public ImportCandidateItem(DiscoveredServerCandidate candidate)
    {
        Candidate = candidate;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
